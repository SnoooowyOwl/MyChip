/**
 * accelerator_v7
 * - 3x6 systolic，时间域 3-tap 累加；与原接口/地址保持一致（addra 为“字节偏移”）
 * - 修复点：权重持续注入（循环 0→1→2），不再只在 t=0/1/2 注一次
 *           计算流水与 AXI 解耦；读口组合
 */
 /*三行 line buffer：前 4 个像素全是 -4，后面全是 +4（便于手算、复现）。
权重 3×3 全是 1。
发送 CMD_START_RELU = 0x0001_FFFF（ReLU 开启）。
结果还是从 BASE+64/+68/+72/+76 读，写回 DMEM 0x8000_0200（word 128..131）。
期望结果（ReLU 后、8bit 截断）
对 16 列做 3×3 卷积（3 行都同样的[-4,-4,-4,-4, +4... ]，权重全 1），14 个输出依次为：

[ 0, 0, 0, 12, 36, 36, 36, 36, 36, 36, 36, 36, 36, 36 ]
打包成 4×word（每 word = {out[i], out[i+1], out[i+2], out[i+3]}，高字节在前）：

BASE+64 : 0x0000000C
BASE+68 : 0x24242424
BASE+72 : 0x24242424
BASE+76 : 0x24240000
因此写回到 DMEM（0x8000_0200，word 128..131）应看到：

memory[128] = 0x0000000C
memory[129] = 0x24242424
memory[130] = 0x24242424
memory[131] = 0x24240000

机器码：
700002b7
fff00313
0062a023

fcfcf337
cfc36313
0062a223
04040337
40436313
0062a423
0062a623
0062a823

fcfcf337
cfc36313
0062aa23
04040337
40436313
0062ac23
0062ae23
0262a023

fcfcf337
cfc36313
0262a223
04040337
40436313
0262a423
0262a623
0262a823

01010337
10136313
0262aa23
0262ac23
01000337
0262ae23

00020337
fff30313
0062a023

00100313
0002a383
fe639ee3

80000437
20040413
0402a383
00742023
0442a383
00742223
0482a383
00742423
04c2a383
00742623
0000006f
*/
module accelerator (
    input  logic        clka,
    input  logic        wea,
    input  logic        ena,
    input  logic [10:0] addra,   // 传入“字节”地址；若顶层给“字地址”，请把下面 ADDR_* 全部 /4
    input  logic [31:0] dina,
    output logic [31:0] douta,
    input  logic        rst_ni
);

  // ---------- 参数 ----------
  localparam int SA_R = 3;
  localparam int SA_C = 6;
  localparam int KX   = 3;
  localparam int NUM_OUT = 14;
  localparam int PE_LAT  = 1;                 // pe_stream 对 a 有 1 拍寄存
  localparam int FILL = SA_C + (KX - 1); // = 6 + 2 = 8

  typedef enum logic [1:0] { IDLE, RUN, DONE } state_e;

  // ---------- 地址映射（字节偏移） ----------
  localparam ADDR_CTRL_STATUS    = 11'h000; // +0
  // Line Buffer
  localparam ADDR_LB_0_3         = 11'h004; // +4
  localparam ADDR_LB_4_7         = 11'h008;
  localparam ADDR_LB_8_11        = 11'h00C;
  localparam ADDR_LB_12_15       = 11'h010;
  localparam ADDR_LB_16_19       = 11'h014;
  localparam ADDR_LB_20_23       = 11'h018;
  localparam ADDR_LB_24_27       = 11'h01C;
  localparam ADDR_LB_28_31       = 11'h020;
  localparam ADDR_LB_32_35       = 11'h024;
  localparam ADDR_LB_36_39       = 11'h028;
  localparam ADDR_LB_40_43       = 11'h02C;
  localparam ADDR_LB_44_47       = 11'h030;
  // Weights
  localparam ADDR_WEIGHTS_0_3    = 11'h034; // +52
  localparam ADDR_WEIGHTS_4_7    = 11'h038; // +56
  localparam ADDR_WEIGHTS_8      = 11'h03C; // +60
  // Results
  localparam ADDR_RESULT_0_3     = 11'h040; // +64
  localparam ADDR_RESULT_4_7     = 11'h044; // +68
  localparam ADDR_RESULT_8_11    = 11'h048; // +72
  localparam ADDR_RESULT_12_13   = 11'h04C; // +76

  // ---------- 命令 ----------
  localparam CMD_START_RELU      = 32'h0001_FFFF;
  localparam CMD_START_NO_RELU   = 32'h0000_FFFF;
  localparam CMD_RESET_PSUMS     = 32'hFFFF_FFFF;
  localparam CMD_SHIFT_LINES     = 32'h0000_0200;

  // ---------- 寄存器 ----------
  // 行缓冲（3x16）
  reg  signed [7:0] line_buffer [0:2][0:15];
  // 权重（3x3, 按行展平 0..8）
  reg         [7:0] weights     [0:8];

  // 结果（低 8 位）
  reg  [7:0]        final_results [0:13];

  state_e           state;
  reg   [31:0]      status_reg;
  reg               relu_en_reg;

  // 计数/滑窗寄存
  reg  [5:0]        t;        // 0..(15+FILL)
  reg  [4:0]        out_idx;  // 0..13
  reg  signed [18:0] vsum_z1, vsum_z2;

  // 核列选择：0/1/2 循环，用于持续注入 3 列权重
  reg  [1:0]        ksel;

  // 权重列移位寄存器（每列 3 行）
  reg  signed [8:0] wcol_pipe [0:SA_C-1][0:SA_R-1];

  // ---------- 西侧像素输入 & 阵列布线 ----------
  wire signed [7:0] a_west [0:SA_R-1];
  wire signed [7:0] a_bus  [0:SA_R-1][0:SA_C];   // a_bus[r][0] = a_west[r]
  wire signed [16:0] p_bus [0:SA_R-1][0:SA_C-1];

  genvar r, c;
  generate
    for (r = 0; r < SA_R; r++) begin : GEN_WEST
      assign a_west[r]   = (t <= 6'd15) ? line_buffer[r][t] : 8'sd0;
      assign a_bus[r][0] = a_west[r];
    end
  endgenerate

  // —— 修复点：持续注入 3 列权重（0→1→2 循环）——
  wire signed [8:0] wcol_in [0:SA_R-1];
  // 行 0（weights[0..2]）
  assign wcol_in[0] = (ksel==2'd0) ? {1'b0,weights[0]} :
                      (ksel==2'd1) ? {1'b0,weights[1]} :
                                     {1'b0,weights[2]};
  // 行 1（weights[3..5]）
  assign wcol_in[1] = (ksel==2'd0) ? {1'b0,weights[3]} :
                      (ksel==2'd1) ? {1'b0,weights[4]} :
                                     {1'b0,weights[5]};
  // 行 2（weights[6..8]）
  assign wcol_in[2] = (ksel==2'd0) ? {1'b0,weights[6]} :
                      (ksel==2'd1) ? {1'b0,weights[7]} :
                                     {1'b0,weights[8]};

  // 6 列 PE：一拍乘法 + a 右传
  generate
    for (r = 0; r < SA_R; r++) begin : GEN_ROW
      for (c = 0; c < SA_C; c++) begin : GEN_COL
        pe_stream u_pe (
          .clk    (clka),
          .rst_ni (rst_ni),
          .run    (state==RUN),
          .a_in   (a_bus[r][c]),
          .w_in   (wcol_pipe[c][r]),
          .a_out  (a_bus[r][c+1]),
          .p_out  (p_bus[r][c])
        );
      end
    end
  endgenerate

  // 右边界当前列竖向求和
  wire signed [18:0] vsum_now =
      $signed(p_bus[0][SA_C-1]) + $signed(p_bus[1][SA_C-1]) + $signed(p_bus[2][SA_C-1]);

  // 三拍时间滑窗（3 列求和）
  wire signed [20:0] wsum_3tap = $signed(vsum_now) + $signed(vsum_z1) + $signed(vsum_z2);

  // ReLU（可选）+ 取低 8 位
  wire signed [31:0] wsum_32 = wsum_3tap;
  wire signed [31:0] after_relu = (relu_en_reg && wsum_32[31]) ? 32'sd0 : wsum_32;
  wire [7:0]         u8_out = after_relu[7:0];
    // 1) 声明寄存器并作为输出
    // 1) 声明寄存器并作为输出
    reg [31:0] douta_q;
    assign douta = douta_q;

    // 2) 用组合 case 生成“要读的值”
    logic [31:0] douta_comb;
    always_comb begin
    unique case (addra)
        ADDR_CTRL_STATUS : douta_comb = status_reg;
        ADDR_RESULT_0_3  : douta_comb = { final_results[0],  final_results[1],
                                        final_results[2],  final_results[3] };
        ADDR_RESULT_4_7  : douta_comb = { final_results[4],  final_results[5],
                                        final_results[6],  final_results[7] };
        ADDR_RESULT_8_11 : douta_comb = { final_results[8],  final_results[9],
                                        final_results[10], final_results[11] };
        ADDR_RESULT_12_13: douta_comb = { final_results[12], final_results[13], 16'h0000 };
        default          : douta_comb = 32'h0;
    endcase
    end

    // 3) 在“读拍”（req 有效且 wea=0）把组合结果寄存
    always_ff @(posedge clka or negedge rst_ni) begin
    if (!rst_ni) begin
        douta_q <= 32'h0;
    end else if (ena && !wea) begin
        // ena来自 axi2mem 的 req_o；!wea 表示读
        douta_q <= douta_comb;
    end
    end





  // ---------- 时序：写口 + 计算流水（解耦 AXI） ----------
  always_ff @(posedge clka or negedge rst_ni) begin
    if (!rst_ni) begin
      state       <= IDLE;
      status_reg  <= 32'h0;
      relu_en_reg <= 1'b0;
      t           <= '0;
      out_idx     <= '0;
      vsum_z1     <= '0;
      vsum_z2     <= '0;
      ksel        <= 2'd0;
      // 清存储
      for (int i=0;i<3;i++) for (int j=0;j<16;j++) line_buffer[i][j] <= '0;
      for (int i=0;i<9;i++)  weights[i] <= '0;
      for (int i=0;i<14;i++) final_results[i] <= '0;
      for (int cc=0; cc<SA_C; cc++) begin
        wcol_pipe[cc][0] <= '0;
        wcol_pipe[cc][1] <= '0;
        wcol_pipe[cc][2] <= '0;
      end
    end else begin
      // ---- 写口（仅在 AXI 写时采样）----
      if (ena && wea) begin
        unique case (addra)
          // 控制
          ADDR_CTRL_STATUS: begin
            if (dina == CMD_RESET_PSUMS) begin
              for (int i=0;i<14;i++) final_results[i] <= '0;
              status_reg  <= 32'h0;
              state       <= IDLE;
              t           <= '0;
              out_idx     <= '0;
              vsum_z1     <= '0;
              vsum_z2     <= '0;
              ksel        <= 2'd0;
              for (int cc=0; cc<SA_C; cc++) begin
                wcol_pipe[cc][0] <= '0;
                wcol_pipe[cc][1] <= '0;
                wcol_pipe[cc][2] <= '0;
              end
            end
            else if (dina == CMD_START_RELU || dina == CMD_START_NO_RELU) begin
              relu_en_reg <= (dina == CMD_START_RELU);
              status_reg  <= 32'h0;
              state       <= RUN;
              t           <= '0;
              out_idx     <= '0;
              vsum_z1     <= '0;
              vsum_z2     <= '0;
              ksel        <= 2'd0; // 从权重列 0 开始循环注入
              for (int cc=0; cc<SA_C; cc++) begin
                wcol_pipe[cc][0] <= '0;
                wcol_pipe[cc][1] <= '0;
                wcol_pipe[cc][2] <= '0;
              end
            end
            else if (dina == CMD_SHIFT_LINES) begin
              for (int i=0;i<16;i++) begin
                line_buffer[2][i] <= line_buffer[1][i];
                line_buffer[1][i] <= line_buffer[0][i];
              end
            end
          end

          // Line Buffer 写入
          ADDR_LB_0_3:    begin line_buffer[0][0]<=dina[31:24]; line_buffer[0][1]<=dina[23:16]; line_buffer[0][2]<=dina[15:8];  line_buffer[0][3]<=dina[7:0];   end
          ADDR_LB_4_7:    begin line_buffer[0][4]<=dina[31:24]; line_buffer[0][5]<=dina[23:16]; line_buffer[0][6]<=dina[15:8];  line_buffer[0][7]<=dina[7:0];   end
          ADDR_LB_8_11:   begin line_buffer[0][8]<=dina[31:24]; line_buffer[0][9]<=dina[23:16]; line_buffer[0][10]<=dina[15:8]; line_buffer[0][11]<=dina[7:0];  end
          ADDR_LB_12_15:  begin line_buffer[0][12]<=dina[31:24];line_buffer[0][13]<=dina[23:16];line_buffer[0][14]<=dina[15:8]; line_buffer[0][15]<=dina[7:0];  end

          ADDR_LB_16_19:  begin line_buffer[1][0]<=dina[31:24]; line_buffer[1][1]<=dina[23:16]; line_buffer[1][2]<=dina[15:8];  line_buffer[1][3]<=dina[7:0];   end
          ADDR_LB_20_23:  begin line_buffer[1][4]<=dina[31:24]; line_buffer[1][5]<=dina[23:16]; line_buffer[1][6]<=dina[15:8];  line_buffer[1][7]<=dina[7:0];   end
          ADDR_LB_24_27:  begin line_buffer[1][8]<=dina[31:24]; line_buffer[1][9]<=dina[23:16]; line_buffer[1][10]<=dina[15:8]; line_buffer[1][11]<=dina[7:0];  end
          ADDR_LB_28_31:  begin line_buffer[1][12]<=dina[31:24];line_buffer[1][13]<=dina[23:16];line_buffer[1][14]<=dina[15:8]; line_buffer[1][15]<=dina[7:0];  end

          ADDR_LB_32_35:  begin line_buffer[2][0]<=dina[31:24]; line_buffer[2][1]<=dina[23:16]; line_buffer[2][2]<=dina[15:8];  line_buffer[2][3]<=dina[7:0];   end
          ADDR_LB_36_39:  begin line_buffer[2][4]<=dina[31:24]; line_buffer[2][5]<=dina[23:16]; line_buffer[2][6]<=dina[15:8];  line_buffer[2][7]<=dina[7:0];   end
          ADDR_LB_40_43:  begin line_buffer[2][8]<=dina[31:24]; line_buffer[2][9]<=dina[23:16]; line_buffer[2][10]<=dina[15:8]; line_buffer[2][11]<=dina[7:0];  end
          ADDR_LB_44_47:  begin line_buffer[2][12]<=dina[31:24];line_buffer[2][13]<=dina[23:16];line_buffer[2][14]<=dina[15:8]; line_buffer[2][15]<=dina[7:0];  end

          // 权重写入
          ADDR_WEIGHTS_0_3: begin weights[0]<=dina[31:24]; weights[1]<=dina[23:16]; weights[2]<=dina[15:8];  weights[3]<=dina[7:0];  end
          ADDR_WEIGHTS_4_7: begin weights[4]<=dina[31:24]; weights[5]<=dina[23:16]; weights[6]<=dina[15:8];  weights[7]<=dina[7:0];  end
          ADDR_WEIGHTS_8  : begin weights[8]<=dina[31:24]; end

          default: /* no-op */ ;
        endcase
      end

      // ---- 计算流水（不依赖 ena/wea，每拍都跑）----
      if (state == RUN) begin
        // 权重列右移（从右往左拷贝，避免组合环）
        for (int cc=SA_C-1; cc>=1; cc--) begin
          wcol_pipe[cc][0] <= wcol_pipe[cc-1][0];
          wcol_pipe[cc][1] <= wcol_pipe[cc-1][1];
          wcol_pipe[cc][2] <= wcol_pipe[cc-1][2];
        end
        // 最左列注入 —— 现在每拍都会注入 (0/1/2 循环)
        wcol_pipe[0][0] <= wcol_in[0];
        wcol_pipe[0][1] <= wcol_in[1];
        wcol_pipe[0][2] <= wcol_in[2];

        // ksel 0/1/2 循环
        ksel <= (ksel==2'd2) ? 2'd0 : (ksel + 2'd1);

        // 三拍时间滑窗寄存
        vsum_z2 <= vsum_z1;
        vsum_z1 <= vsum_now;

        // 采样输出
        if (t >= FILL && out_idx < NUM_OUT) begin
          final_results[out_idx] <= u8_out;
          out_idx <= out_idx + 1'b1;
        end

        // 拍计数
        t <= t + 6'd1;

        // 完成
        if (out_idx == NUM_OUT) begin
          state      <= DONE;
          status_reg <= 32'h0000_0001;
        end
      end
    end
  end

endmodule


// ---------- 简单 PE：一拍寄存 a，再乘 ----------
module pe_stream (
  input  logic              clk,
  input  logic              rst_ni,
  input  logic              run,
  input  logic signed [7:0] a_in,
  input  logic signed [8:0] w_in,
  output logic signed [7:0] a_out,
  output logic signed [16:0] p_out
);
  logic signed [7:0] a_reg;

  always_ff @(posedge clk or negedge rst_ni) begin
    if (!rst_ni)       a_reg <= '0;
    else if (run)      a_reg <= a_in;
  end

  assign a_out = a_reg;
  assign p_out = $signed(a_reg) * $signed(w_in);
endmodule
