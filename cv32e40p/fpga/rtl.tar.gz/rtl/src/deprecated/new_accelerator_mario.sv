/**
 * @brief accelerator 模块 (三人协作版 - 单文件分块架构)
 * @details 
 * - Member 1: 负责 block_axi_master (总线读写)
 * - Member 2: 负责 block_compute_core (计算、缓存)
 * - Member 3: 负责 block_controller (状态机、寄存器)
 */
module accelerator (
    input  logic        clk_i,
    input  logic        rst_ni,

    // =========================================================================
    // [接口 1] Slave Interface: CPU 配置通道 (保持不变)
    // =========================================================================
    input  logic        slv_en_i,    // 原 ena
    input  logic        slv_we_i,    // 原 wea
    input  logic [10:0] slv_addr_i,  // 原 addra
    input  logic [31:0] slv_wdata_i, // 原 dina
    output logic [31:0] slv_rdata_o, // 原 douta

    // =========================================================================
    // [接口 2] Master Interface: AXI4 主动读写通道 (新增)
    // =========================================================================
    // 读地址通道
    output logic [31:0] m_axi_araddr,
    output logic [7:0]  m_axi_arlen,
    output logic [2:0]  m_axi_arsize,
    output logic [1:0]  m_axi_arburst,
    output logic        m_axi_arvalid,
    input  logic        m_axi_arready,
    // 读数据通道
    input  logic [31:0] m_axi_rdata,
    input  logic [1:0]  m_axi_rresp,
    input  logic        m_axi_rlast,
    input  logic        m_axi_rvalid,
    output logic        m_axi_rready,
    // 写地址通道
    output logic [31:0] m_axi_awaddr,
    output logic [7:0]  m_axi_awlen,
    output logic [2:0]  m_axi_awsize,
    output logic [1:0]  m_axi_awburst,
    output logic        m_axi_awvalid,
    input  logic        m_axi_awready,
    // 写数据通道
    output logic [31:0] m_axi_wdata,
    output logic [3:0]  m_axi_wstrb,
    output logic        m_axi_wlast,
    output logic        m_axi_wvalid,
    input  logic        m_axi_wready,
    // 写响应通道
    input  logic [1:0]  m_axi_bresp,
    input  logic        m_axi_bvalid,
    output logic        m_axi_bready
);

    // =========================================================================
    //                      内部握手信号定义 (Internal Handshake)
    //           (这是你们三人的"法律条约"，不要随意修改变量名)
    // =========================================================================

    // --- Group A: 控制器 (M3) -> 总线 (M1) ---
    logic        dma_rd_req;        // [脉冲] 请求开始读
    logic [31:0] dma_rd_addr;       // [电平] 读源地址
    logic [7:0]  dma_rd_len;        // [电平] 读长度 (AXI len)
    logic        dma_rd_done;       // [脉冲] 反馈：读事务结束

    logic        dma_wr_req;        // [脉冲] 请求开始写
    logic [31:0] dma_wr_addr;       // [电平] 写目的地址
    logic [7:0]  dma_wr_len;        // [电平] 写长度
    logic        dma_wr_done;       // [脉冲] 反馈：写事务结束

    // --- Group B: 总线 (M1) -> 计算核心 (M2) (数据流) ---
    logic        stream_valid;      // [电平] 数据有效 (对应 AXI RVALID & RREADY)
    logic [31:0] stream_data;       // [数据] 读到的数据 (对应 AXI RDATA)

    // --- Group C: 控制器 (M3) -> 计算核心 (M2) (配置与控制) ---
    logic        core_load_wgt;     // [电平] 1=流数据存入权重
    logic        core_load_buf_a;   // [电平] 1=流数据存入 Buffer A
    logic        core_load_buf_b;   // [电平] 1=流数据存入 Buffer B
    
    logic        core_calc_start;   // [脉冲] 启动计算阵列
    logic        core_use_buf_b;    // [电平] 0=算A组, 1=算B组 (Ping-Pong选择)
    logic        core_calc_done;    // [脉冲] 反馈：计算完成

    // --- Group D: 计算核心 (M2) -> 总线 (M1) (结果回写) ---
    // 假设有 4 个核，每个核输出一个 32位 结果
    logic [31:0] core_res_0;
    logic [31:0] core_res_1;
    logic [31:0] core_res_2;
    logic [31:0] core_res_3;


    // =========================================================================
    // SECTION 1: Member 3 - Main Controller (FSM & Registers)
    // =========================================================================
    begin : block_controller
        // 1. 定义寄存器 (源地址, 目的地址, 状态, 启动位)
        logic [31:0] reg_src_addr;
        logic [31:0] reg_dst_addr;
        logic [31:0] reg_wgt_addr;
        logic [31:0] reg_status;
        
        // 2. 定义状态机状态
        typedef enum logic [3:0] {
            S_IDLE,
            S_LOAD_WGT,      // 读权重
            S_PRE_FILL_A,    // 预读 Buffer A
            S_CALC_A_LOAD_B, // 算 A 读 B
            S_CALC_B_LOAD_A, // 算 B 读 A
            S_WRITE_BACK     // 写回结果
        } state_t;
        state_t state, next_state;

        // 3. Slave 接口逻辑 (CPU 配置寄存器)
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                // 复位逻辑...
            end else if (slv_en_i && slv_we_i) begin
                // TODO: Member 3 在这里写寄存器写入逻辑
                // case (slv_addr_i) ...
            end
        end

        // 4. 主状态机逻辑
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) state <= S_IDLE;
            else state <= next_state;
        end

        always_comb begin
            // 默认输出
            dma_rd_req = 0; core_load_wgt = 0; // ...
            next_state = state;

            case (state)
                S_IDLE: begin
                    // TODO: Member 3 在这里写状态跳转
                    // if (start_bit) next_state = S_LOAD_WGT;
                end
                
                S_LOAD_WGT: begin
                    // TODO: Member 3 指挥 Member 1 去读权重
                    // dma_rd_req = 1; core_load_wgt = 1;
                end
                
                // ... 其他状态 ...
            endcase
        end
    end : block_controller


    // =========================================================================
    // SECTION 2: Member 1 - AXI Master Controller (Bus Interface)
    // =========================================================================
    begin : block_axi_master
        // 1. 读通道状态机
        typedef enum logic [1:0] { R_IDLE, R_ADDR, R_DATA } rd_state_t;
        rd_state_t r_state;
        logic [7:0] r_cnt; // 读计数器

        // TODO: Member 1 实现 AXI 读逻辑
        // 提示: 当 dma_rd_req 来时，进入 R_ADDR 发送 ARVALID
        //       当 m_axi_arready 来时，进入 R_DATA
        //       在 R_DATA 状态，当 m_axi_rvalid && m_axi_rready 时，拉高 stream_valid

        assign stream_data = m_axi_rdata; // 直接透传数据
        // assign stream_valid = ... 

        // 2. 写通道状态机
        // TODO: Member 1 实现 AXI 写逻辑
        // 提示: 当 dma_wr_req 来时，把 core_res_0~3 打包发送

        // 3. 常量赋值
        assign m_axi_arsize = 3'b010; // 4 bytes
        assign m_axi_arburst = 2'b01; // INCR
        // ... 其他固定信号
    end : block_axi_master


    // =========================================================================
    // SECTION 3: Member 2 - Compute Core (Datapath & Buffers)
    // =========================================================================
    begin : block_compute_core
        // =====================================================================
        // 1. 内部存储资源定义
        // =====================================================================
        // 权重: 4个核 x 9个权重 (每个8bit)
        // 映射: weights[core_id][weight_idx]
        logic signed [7:0] weights [0:3][0:8];
        
        // Ping-Pong Buffer: 存储 4x4 输入图片 (16 bytes)
        // 映射: buf[row * 4 + col]
        logic signed [7:0] buf_A [0:15];
        logic signed [7:0] buf_B [0:15];
        
        // 结果寄存器: 4个核 x 4个输出像素 (2x2 output)
        logic signed [7:0] res_internal [0:3][0:3];

        // 加载计数器 (用于记录 stream_data 来了多少次)
        logic [3:0] load_cnt;
        
        // 计算状态机信号
        logic [2:0] calc_step; // 0..3 对应 2x2 输出的四个位置
        logic       is_computing;

        // =====================================================================
        // 2. 数据加载逻辑 (Load Logic)
        // =====================================================================
        // 当 stream_valid 有效时，根据 enable 信号把数据填入 RAM
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                load_cnt <= 0;
            end else begin
                // 如果任意加载使能有效，且数据来了
                if (stream_valid && (core_load_wgt || core_load_buf_a || core_load_buf_b)) begin
                    load_cnt <= load_cnt + 1;
                end 
                // 如果没有加载任务，重置计数器
                else if (!(core_load_wgt || core_load_buf_a || core_load_buf_b)) begin
                    load_cnt <= 0;
                end
            end
        end

        // 写入 Buffer A (4x4 = 16 bytes = 4 words)
        always_ff @(posedge clk_i) begin
            if (stream_valid && core_load_buf_a) begin
                // stream_data 是 32bit: {byte3, byte2, byte1, byte0}
                buf_A[load_cnt*4 + 0] <= stream_data[7:0];
                buf_A[load_cnt*4 + 1] <= stream_data[15:8];
                buf_A[load_cnt*4 + 2] <= stream_data[23:16];
                buf_A[load_cnt*4 + 3] <= stream_data[31:24];
            end
        end

        // 写入 Buffer B
        always_ff @(posedge clk_i) begin
            if (stream_valid && core_load_buf_b) begin
                buf_B[load_cnt*4 + 0] <= stream_data[7:0];
                buf_B[load_cnt*4 + 1] <= stream_data[15:8];
                buf_B[load_cnt*4 + 2] <= stream_data[23:16];
                buf_B[load_cnt*4 + 3] <= stream_data[31:24];
            end
        end

        // 写入权重 (4核 x 9权重 = 36 bytes = 9 words)
        // 简单的线性映射：前9个字节给核0，次9个给核1...
        // 为了简化，这里假设 stream_data 顺序是:
        // Word0: C0_W0..3, Word1: C0_W4..7, Word2: C0_W8...
        integer w_core_idx;
        integer w_idx_base;
        always_ff @(posedge clk_i) begin
            if (stream_valid && core_load_wgt) begin
                // 这是一个简化的映射逻辑，实际需要 Member 3 配合发送正确顺序
                // 这里假设 load_cnt 0-2 是 Core0, 3-5 是 Core1...
                w_core_idx = load_cnt / 3; 
                w_idx_base = (load_cnt % 3) * 4;
                
                if (w_core_idx < 4) begin
                    if (w_idx_base <= 8) weights[w_core_idx][w_idx_base+0] <= stream_data[7:0];
                    if (w_idx_base+1 <= 8) weights[w_core_idx][w_idx_base+1] <= stream_data[15:8];
                    if (w_idx_base+2 <= 8) weights[w_core_idx][w_idx_base+2] <= stream_data[23:16];
                    if (w_idx_base+3 <= 8) weights[w_core_idx][w_idx_base+3] <= stream_data[31:24];
                end
            end
        end

        // =====================================================================
        // 3. 计算核心逻辑 (Compute Engine)
        // =====================================================================
        
        // 3.1 计算状态机
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                is_computing <= 0;
                calc_step <= 0;
                core_calc_done <= 0;
            end else begin
                core_calc_done <= 0; // 脉冲复位

                if (core_calc_start) begin
                    is_computing <= 1;
                    calc_step <= 0;
                end else if (is_computing) begin
                    if (calc_step == 3) begin
                        is_computing <= 0;
                        core_calc_done <= 1; // 完成信号
                    end else begin
                        calc_step <= calc_step + 1;
                    end
                end
            end
        end

        // 3.2 组合逻辑阵列 (4个核并行)
        // 定义当前使用的 Buffer
        logic signed [7:0] cur_buf [0:15];
        assign cur_buf = core_use_buf_b ? buf_B : buf_A;

        genvar k;
        generate
            for (k = 0; k < 4; k = k + 1) begin : gen_cores
                // 每个核的局部变量
                logic signed [16:0] psum;
                logic signed [7:0]  pixel_window [0:8];
                logic signed [7:0]  wgt_window [0:8];
                logic signed [16:0] mult_res [0:8];
                
                // 3.2.1 滑动窗口逻辑 (根据 calc_step 选择 3x3 区域)
                // Input 4x4:
                // 0  1  2  3
                // 4  5  6  7
                // 8  9  10 11
                // 12 13 14 15
                // Output 2x2:
                // Step 0: Top-Left (Start at 0)
                // Step 1: Top-Right (Start at 1)
                // Step 2: Btm-Left (Start at 4)
                // Step 3: Btm-Right (Start at 5)
                
                integer start_idx;
                always_comb begin
                    case (calc_step)
                        0: start_idx = 0;
                        1: start_idx = 1;
                        2: start_idx = 4;
                        3: start_idx = 5;
                        default: start_idx = 0;
                    endcase
                    
                    // 提取 3x3 窗口
                    pixel_window[0] = cur_buf[start_idx + 0]; pixel_window[1] = cur_buf[start_idx + 1]; pixel_window[2] = cur_buf[start_idx + 2];
                    pixel_window[3] = cur_buf[start_idx + 4]; pixel_window[4] = cur_buf[start_idx + 5]; pixel_window[5] = cur_buf[start_idx + 6];
                    pixel_window[6] = cur_buf[start_idx + 8]; pixel_window[7] = cur_buf[start_idx + 9]; pixel_window[8] = cur_buf[start_idx + 10];
                    
                    // 提取当前核的权重
                    wgt_window = weights[k];
                end

                // 3.2.2 乘法阵列 (9个乘法器)
                integer m;
                always_comb begin
                    for (m = 0; m < 9; m = m + 1) begin
                        mult_res[m] = pixel_window[m] * wgt_window[m];
                    end
                end

                // 3.2.3 加法树
                assign psum = mult_res[0] + mult_res[1] + mult_res[2] +
                              mult_res[3] + mult_res[4] + mult_res[5] +
                              mult_res[6] + mult_res[7] + mult_res[8];

                // 3.2.4 ReLU + 截断 (存入结果寄存器)
                always_ff @(posedge clk_i) begin
                    if (is_computing) begin
                        // ReLU: if psum < 0 -> 0
                        if (psum[16]) begin // 符号位为1 (负数)
                            res_internal[k][calc_step] <= 8'd0;
                        end 
                        // 饱和截断: if psum > 255 -> 255
                        else if (|psum[15:8]) begin // 高位有值
                            res_internal[k][calc_step] <= 8'd255;
                        end 
                        else begin
                            res_internal[k][calc_step] <= psum[7:0];
                        end
                    end
                end
            end
        endgenerate

        // =====================================================================
        // 4. 结果输出连接
        // =====================================================================
        // 将每个核计算出的 4 个 8-bit 结果打包成 32-bit 输出
        // 格式: {Pixel3, Pixel2, Pixel1, Pixel0}
        assign core_res_0 = {res_internal[0][3], res_internal[0][2], res_internal[0][1], res_internal[0][0]};
        assign core_res_1 = {res_internal[1][3], res_internal[1][2], res_internal[1][1], res_internal[1][0]};
        assign core_res_2 = {res_internal[2][3], res_internal[2][2], res_internal[2][1], res_internal[2][0]};
        assign core_res_3 = {res_internal[3][3], res_internal[3][2], res_internal[3][1], res_internal[3][0]};

    end : block_compute_core


endmodule
