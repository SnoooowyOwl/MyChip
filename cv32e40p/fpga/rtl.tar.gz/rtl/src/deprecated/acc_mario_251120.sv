`timescale 1ns / 1ps

/**
 * @brief accelerator 模块 (v6 - Final Architecture)
 * @details 
 * - 架构: Master DMA + Ping-Pong Buffer + Dual Mode (Conv/FC)
 * - Member 1: AXI Master (负责搬运数据流，以及将计算结果写回内存)
 * - Member 2: Compute Core (负责双缓存管理、Conv滑动计算、FC累加计算)
 * - Member 3: Controller (负责 Ping-Pong 调度、模式切换、寄存器管理)
 */
module accelerator (
    input  logic        clk_i,
    input  logic        rst_ni,

    // =========================================================================
    // [接口 1] Slave Interface: CPU 配置通道 (保持不变)
    // =========================================================================
    input  logic        slv_en_i,
    input  logic        slv_we_i,
    input  logic [10:0] slv_addr_i,
    input  logic [31:0] slv_wdata_i,
    output logic [31:0] slv_rdata_o,

    // =========================================================================
    // [接口 2] Master Interface: AXI4 主动读写通道 (保持不变)
    // =========================================================================
    // 读地址通道
    output logic [31:0] m_axi_araddr,
    output logic [7:0]  m_axi_arlen,
    output logic [2:0]  m_axi_arsize,
    output logic [1:0]  m_axi_arburst,
    output logic        m_axi_arvalid,
    input  logic        m_axi_arready,
    // 读数据通道
    input  logic [31:0] m_axi_rdata,
    input  logic [1:0]  m_axi_rresp,
    input  logic        m_axi_rlast,
    input  logic        m_axi_rvalid,
    output logic        m_axi_rready,
    // 写地址通道
    output logic [31:0] m_axi_awaddr,
    output logic [7:0]  m_axi_awlen,
    output logic [2:0]  m_axi_awsize,
    output logic [1:0]  m_axi_awburst,
    output logic        m_axi_awvalid,
    input  logic        m_axi_awready,
    // 写数据通道
    output logic [31:0] m_axi_wdata,
    output logic [3:0]  m_axi_wstrb,
    output logic        m_axi_wlast,
    output logic        m_axi_wvalid,
    input  logic        m_axi_wready,
    // 写响应通道
    input  logic [1:0]  m_axi_bresp,
    input  logic        m_axi_bvalid,
    output logic        m_axi_bready
);

    // =========================================================================
    //                      内部握手信号定义 (Internal Handshake)
    // =========================================================================

    // --- Group A: 控制器 (M3) -> 总线 (M1) [DMA 指令] ---
    logic        dma_rd_req;        // [脉冲] 请求开始读事务
    logic [31:0] dma_rd_addr;       // [电平] 读源地址
    logic [7:0]  dma_rd_len;        // [电平] 读长度 (AXI len)
    logic        dma_rd_done;       // [脉冲] 反馈：读事务结束

    logic        dma_wr_req;        // [脉冲] 请求开始写事务
    logic [31:0] dma_wr_addr;       // [电平] 写目的地址
    logic [7:0]  dma_wr_len;        // [电平] 写长度 (Conv模式通常为13，FC模式为0)
    logic        dma_wr_done;       // [脉冲] 反馈：写事务结束

    // --- Group B: 总线 (M1) -> 计算核心 (M2) [数据流] ---
    logic        stream_valid;      // [电平] 数据有效 (表示 stream_data 可用)
    logic [31:0] stream_data;       // [数据] 读到的数据流

    // --- Group C: 控制器 (M3) -> 计算核心 (M2) [控制指令] ---
    // 1. 全局配置
    logic        ctrl_mode_fc;      // [电平] 0=Conv模式(滑动窗口), 1=FC模式(定点累加)
    
    // 2. 数据加载控制 (Input Logic)
    logic        ctrl_load_en;      // [电平] 1=允许接收 stream_valid 数据
    logic        ctrl_load_is_wgt;  // [电平] 1=数据载入权重寄存器, 0=数据载入 Ping-Pong Buffer
    logic        ctrl_buf_wr_sel;   // [电平] 0=写入 Buffer A, 1=写入 Buffer B (Ping-Pong 写指针)

    // 3. 计算控制 (Compute Logic)
    logic        ctrl_calc_start;   // [脉冲] 启动计算引擎
    logic        ctrl_buf_rd_sel;   // [电平] 0=使用 Buffer A 计算, 1=使用 Buffer B 计算 (Ping-Pong 读指针)
    logic        ctrl_fc_acc_clear; // [脉冲] (仅FC) 清零累加器，准备计算新的神经元
    logic        stat_calc_done;    // [脉冲] 反馈：计算完成 (Conv为14周期后，FC为1周期后)

    // --- Group D: 计算核心 (M2) -> 总线 (M1) [结果回写] ---
    logic [3:0]  res_rd_addr;       // [M1->M2] 读地址 (Conv: 0~13, FC: 0)
    logic [31:0] res_rd_data;       // [M2->M1] 读数据 (4个核的结果打包成32bit)


    // =========================================================================
    // SECTION 1: Member 3 - Main Controller (FSM & Registers)
    // =========================================================================
    begin : block_controller
        // --- 1. 寄存器定义与地址映射 ---
        localparam ADDR_CTRL   = 11'h000; // Bit 0: Start, Bit 1: Mode (0=Conv, 1=FC)
        localparam ADDR_STATUS = 11'h004; // Bit 0: Busy, Bit 1: Done
        localparam ADDR_SRC    = 11'h008; // 输入数据源地址
        localparam ADDR_DST    = 11'h00C; // 结果目的地址
        localparam ADDR_WGT    = 11'h010; // 权重地址
        localparam ADDR_LEN    = 11'h014; // 循环次数 (Conv: 行数, FC: 分块数)

        logic [31:0] reg_src_addr;
        logic [31:0] reg_dst_addr;
        logic [31:0] reg_wgt_addr;
        logic [31:0] reg_len;
        logic        reg_mode_fc;     // 1=FC, 0=Conv
        logic        reg_start;       // 自复位 Start 信号
        logic        reg_busy;
        logic        reg_done;

        // 内部计数器
        logic [31:0] cnt_loop;        // 当前循环计数
        logic [31:0] curr_src_addr;   // 当前读地址指针
        logic [31:0] curr_dst_addr;   // 当前写地址指针

        // 并行完成标志 (用于 Ping-Pong 握手)
        logic        flag_calc_done;
        logic        flag_dma_rd_done;

        // --- 2. 状态机定义 ---
        typedef enum logic [3:0] {
            S_IDLE,
            S_LOAD_WGT,         // 加载权重
            S_CLR_ACC,          // (FC专用) 清零累加器
            S_PRE_FILL,         // 预读取第一个 Buffer (A)
            S_PP_PHASE_A,       // 算 A，读 B (并行)
            S_WAIT_A,           // 等待 A 阶段完成
            S_CONV_WR_A,        // (Conv专用) 写回 A 的结果
            S_PP_PHASE_B,       // 算 B，读 A (并行)
            S_WAIT_B,           // 等待 B 阶段完成
            S_CONV_WR_B,        // (Conv专用) 写回 B 的结果
            S_FC_FLUSH,         // (FC专用) 循环结束后写回累加器
            S_DONE              // 完成
        } state_t;

        state_t state, next_state;

        // --- 3. Slave 接口逻辑 (CPU 配置) ---
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                reg_src_addr <= '0;
                reg_dst_addr <= '0;
                reg_wgt_addr <= '0;
                reg_len      <= '0;
                reg_mode_fc  <= 1'b0;
                reg_start    <= 1'b0;
            end else if (slv_en_i && slv_we_i) begin
                case (slv_addr_i)
                    ADDR_CTRL: begin
                        reg_start   <= slv_wdata_i[0];
                        reg_mode_fc <= slv_wdata_i[1];
                    end
                    ADDR_SRC: reg_src_addr <= slv_wdata_i;
                    ADDR_DST: reg_dst_addr <= slv_wdata_i;
                    ADDR_WGT: reg_wgt_addr <= slv_wdata_i;
                    ADDR_LEN: reg_len      <= slv_wdata_i;
                    default: ;
                endcase
            end else begin
                reg_start <= 1'b0; // Start 信号仅维持一个周期 (脉冲)
            end
        end

        // Slave 读逻辑
        always_comb begin
            slv_rdata_o = 32'h0;
            case (slv_addr_i)
                ADDR_CTRL:   slv_rdata_o = {30'b0, reg_mode_fc, 1'b0};
                ADDR_STATUS: slv_rdata_o = {30'b0, reg_done, reg_busy};
                ADDR_SRC:    slv_rdata_o = reg_src_addr;
                ADDR_DST:    slv_rdata_o = reg_dst_addr;
                ADDR_WGT:    slv_rdata_o = reg_wgt_addr;
                ADDR_LEN:    slv_rdata_o = reg_len;
                default:     slv_rdata_o = 32'h0;
            endcase
        end

        // --- 4. 主状态机逻辑 (Ping-Pong 调度) ---
        
        // 4a. 状态跳转与计数器更新
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                state            <= S_IDLE;
                cnt_loop         <= '0;
                curr_src_addr    <= '0;
                curr_dst_addr    <= '0;
                flag_calc_done   <= 1'b0;
                flag_dma_rd_done <= 1'b0;
                reg_busy         <= 1'b0;
                reg_done         <= 1'b0;
            end else begin
                state <= next_state;

                // 状态机辅助逻辑
                case (state)
                    S_IDLE: begin
                        reg_done <= 1'b0;
                        if (reg_start) begin
                            reg_busy      <= 1'b1;
                            curr_src_addr <= reg_src_addr;
                            curr_dst_addr <= reg_dst_addr;
                            cnt_loop      <= 32'd0;
                        end
                    end

                    S_LOAD_WGT: begin
                        // 权重加载完，准备加载输入
                    end

                    S_PRE_FILL: begin
                        if (dma_rd_done) begin
                            curr_src_addr <= curr_src_addr + 32'd16; // 指针+16字节
                            cnt_loop      <= cnt_loop + 1;
                        end
                    end

                    // --- Phase A ---
                    S_PP_PHASE_A: begin
                        // 进入此状态时，标志位清零
                        flag_calc_done   <= 1'b0;
                        flag_dma_rd_done <= 1'b0;
                    end
                    S_WAIT_A: begin
                        // 锁存完成信号
                        if (stat_calc_done) flag_calc_done   <= 1'b1;
                        if (dma_rd_done)    flag_dma_rd_done <= 1'b1;
                        
                        // 离开状态时更新指针
                        if (next_state != S_WAIT_A) begin
                            // 如果刚才触发了 DMA 读，则更新源地址和计数
                            if (cnt_loop < reg_len) begin
                                curr_src_addr <= curr_src_addr + 32'd16;
                                cnt_loop      <= cnt_loop + 1;
                            end
                        end
                    end
                    S_CONV_WR_A: begin
                        if (dma_wr_done) curr_dst_addr <= curr_dst_addr + 32'd56; // 14*4=56字节
                    end

                    // --- Phase B ---
                    S_PP_PHASE_B: begin
                        flag_calc_done   <= 1'b0;
                        flag_dma_rd_done <= 1'b0;
                    end
                    S_WAIT_B: begin
                        if (stat_calc_done) flag_calc_done   <= 1'b1;
                        if (dma_rd_done)    flag_dma_rd_done <= 1'b1;

                        if (next_state != S_WAIT_B) begin
                            if (cnt_loop < reg_len) begin
                                curr_src_addr <= curr_src_addr + 32'd16;
                                cnt_loop      <= cnt_loop + 1;
                            end
                        end
                    end
                    S_CONV_WR_B: begin
                        if (dma_wr_done) curr_dst_addr <= curr_dst_addr + 32'd56;
                    end

                    S_DONE: begin
                        reg_busy <= 1'b0;
                        reg_done <= 1'b1;
                    end
                    default: ;
                endcase
            end
        end

        // 4b. 组合逻辑：下一状态与控制信号输出
        always_comb begin
            next_state = state;
            
            // 默认输出
            dma_rd_req       = 1'b0;
            dma_rd_addr      = curr_src_addr;
            dma_rd_len       = 8'd0;
            dma_wr_req       = 1'b0;
            dma_wr_addr      = curr_dst_addr;
            dma_wr_len       = 8'd0;

            ctrl_mode_fc     = reg_mode_fc;
            ctrl_load_en     = 1'b0;
            ctrl_load_is_wgt = 1'b0;
            ctrl_buf_wr_sel  = 1'b0;
            ctrl_calc_start  = 1'b0;
            ctrl_buf_rd_sel  = 1'b0;
            ctrl_fc_acc_clear= 1'b0;
            
            // 结果回读地址 (M1->M2)，Conv模式下由DMA内部计数器控制(这里简化为0)，FC模式固定为0
            res_rd_addr      = 4'd0; 

            case (state)
                S_IDLE: begin
                    if (reg_start) next_state = S_LOAD_WGT;
                end

                S_LOAD_WGT: begin
                    dma_rd_req       = 1'b1; // 触发读
                    dma_rd_addr      = reg_wgt_addr;
                    dma_rd_len       = 8'd8; // 9*4 = 36 bytes -> 9 words (len=8)
                    ctrl_load_en     = 1'b1; // 允许 M2 接收
                    ctrl_load_is_wgt = 1'b1; // 存入权重
                    
                    if (dma_rd_done) begin
                        if (reg_mode_fc) next_state = S_CLR_ACC;
                        else             next_state = S_PRE_FILL;
                    end
                end

                S_CLR_ACC: begin
                    ctrl_fc_acc_clear = 1'b1; // FC模式前清零累加器
                    next_state        = S_PRE_FILL;
                end

                S_PRE_FILL: begin
                    // 读入第一个块到 Buffer A
                    dma_rd_req      = 1'b1;
                    dma_rd_len      = 8'd3; // 16 bytes -> 4 words (len=3)
                    ctrl_load_en    = 1'b1;
                    ctrl_buf_wr_sel = 1'b0; // 写 A
                    
                    if (dma_rd_done) next_state = S_PP_PHASE_A;
                end

                // ================= PHASE A (算A, 读B) =================
                S_PP_PHASE_A: begin
                    // 仅作为触发脉冲的状态
                    ctrl_calc_start = 1'b1; // 触发 M2 算 A
                    ctrl_buf_rd_sel = 1'b0; // M2 读 A

                    // 如果还有数据，触发 DMA 读 B
                    if (cnt_loop < reg_len) begin
                        dma_rd_req      = 1'b1;
                        dma_rd_len      = 8'd3;
                        ctrl_load_en    = 1'b1;
                        ctrl_buf_wr_sel = 1'b1; // DMA 写 B
                    end
                    next_state = S_WAIT_A;
                end

                S_WAIT_A: begin
                    ctrl_buf_rd_sel = 1'b0; // 保持 M2 读 A
                    ctrl_load_en    = 1'b1; // 保持 DMA 写 B 使能
                    ctrl_buf_wr_sel = 1'b1;

                    // 等待条件：计算必须完成。如果发起了DMA，DMA也必须完成。
                    logic wait_dma;
                    wait_dma = (cnt_loop < reg_len); // 是否在等待 DMA

                    if ((flag_calc_done || stat_calc_done) && 
                        (!wait_dma || flag_dma_rd_done || dma_rd_done)) begin
                        
                        if (reg_mode_fc) begin
                            // FC模式：不写回，直接去下一阶段
                            if (cnt_loop >= reg_len) next_state = S_FC_FLUSH; // 算完了
                            else                     next_state = S_PP_PHASE_B;
                        end else begin
                            // Conv模式：必须写回结果
                            next_state = S_CONV_WR_A;
                        end
                    end
                end

                S_CONV_WR_A: begin
                    dma_wr_req = 1'b1;
                    dma_wr_len = 8'd13; // 写 14 个结果 (len=13)
                    // 在此状态下，M1 会读取 M2 的 result_mem
                    // 简化：假设 M1 内部自动处理 res_rd_addr 的递增

                    if (dma_wr_done) begin
                        if (cnt_loop >= reg_len) next_state = S_DONE;
                        else                     next_state = S_PP_PHASE_B;
                    end
                end

                // ================= PHASE B (算B, 读A) =================
                S_PP_PHASE_B: begin
                    ctrl_calc_start = 1'b1; // 触发 M2 算 B
                    ctrl_buf_rd_sel = 1'b1; // M2 读 B

                    if (cnt_loop < reg_len) begin
                        dma_rd_req      = 1'b1;
                        dma_rd_len      = 8'd3;
                        ctrl_load_en    = 1'b1;
                        ctrl_buf_wr_sel = 1'b0; // DMA 写 A
                    end
                    next_state = S_WAIT_B;
                end

                S_WAIT_B: begin
                    ctrl_buf_rd_sel = 1'b1;
                    ctrl_load_en    = 1'b1;
                    ctrl_buf_wr_sel = 1'b0;

                    logic wait_dma;
                    wait_dma = (cnt_loop < reg_len);

                    if ((flag_calc_done || stat_calc_done) && 
                        (!wait_dma || flag_dma_rd_done || dma_rd_done)) begin
                        
                        if (reg_mode_fc) begin
                            if (cnt_loop >= reg_len) next_state = S_FC_FLUSH;
                            else                     next_state = S_PP_PHASE_A;
                        end else begin
                            next_state = S_CONV_WR_B;
                        end
                    end
                end

                S_CONV_WR_B: begin
                    dma_wr_req = 1'b1;
                    dma_wr_len = 8'd13;

                    if (dma_wr_done) begin
                        if (cnt_loop >= reg_len) next_state = S_DONE;
                        else                     next_state = S_PP_PHASE_A;
                    end
                end

                // ================= FC 结束写回 =================
                S_FC_FLUSH: begin
                    dma_wr_req  = 1'b1;
                    dma_wr_len  = 8'd0; // 写 1 个结果 (len=0)
                    res_rd_addr = 4'd0; // FC 结果固定在地址 0

                    if (dma_wr_done) next_state = S_DONE;
                end

                S_DONE: begin
                    // 等待 CPU 清除 Start 或复位
                    if (!reg_start) next_state = S_IDLE;
                end
                default: next_state = S_IDLE;
            endcase
        end

    end : block_controller


    // =========================================================================
    // SECTION 2: Member 1 - AXI Master Controller (Bus Interface)
    // =========================================================================
    begin : block_axi_master
        // TODO: 实现 AXI 读写逻辑，这里先给安全默认值

        // 读地址通道默认值
        assign m_axi_araddr  = dma_rd_addr;
        assign m_axi_arlen   = dma_rd_len;
        assign m_axi_arsize  = 3'b010; // 4 bytes
        assign m_axi_arburst = 2'b01;  // INCR
        assign m_axi_arvalid = dma_rd_req;

        // 读数据通道简单回传到 stream 接口（TODO: 正式实现握手）
        assign m_axi_rready  = 1'b1;   // 暂时总是 ready
        // 这里不真正驱动 stream_valid/stream_data，由更完整逻辑来写
        // 在你当前的独立 tb 中，可以直接绕过 AXI，用 tb 自己拉 stream_*。

        // 写地址通道默认值
        assign m_axi_awaddr  = dma_wr_addr;
        assign m_axi_awlen   = dma_wr_len;
        assign m_axi_awsize  = 3'b010;
        assign m_axi_awburst = 2'b01;
        assign m_axi_awvalid = dma_wr_req;

        // 写数据通道默认值（TODO: 用 res_rd_data 驱动）
        assign m_axi_wdata   = 32'h0;
        assign m_axi_wstrb   = 4'hF;
        assign m_axi_wlast   = 1'b0;
        assign m_axi_wvalid  = 1'b0;

        // 写响应通道
        assign m_axi_bready  = 1'b1;
    end : block_axi_master


    // =========================================================================
    // SECTION 3: Member 2 - Compute Core (Datapath & Buffers)
    // =========================================================================
    begin : block_compute_core
        // ========= 1. 存储资源定义（和 compute_core_standalone 行为一致） =========
        // 权重: 4 核 x 9 参数
        logic signed [7:0] weights0 [0:8];
        logic signed [7:0] weights1 [0:8];
        logic signed [7:0] weights2 [0:8];
        logic signed [7:0] weights3 [0:8];

        // Ping / Pong Buffer
        logic signed [7:0] buf_A [0:15];
        logic signed [7:0] buf_B [0:15];

        // Line Buffer: 3 行 x 16 列
        logic signed [7:0] line0 [0:15];
        logic signed [7:0] line1 [0:15];
        logic signed [7:0] line2 [0:15];

        // Conv 结果 RAM (14 个结果 x 32bit)
        logic [31:0] result_mem [0:13];

        // FC 累加寄存器
        logic signed [31:0] acc0;
        logic signed [31:0] acc1;
        logic signed [31:0] acc2;
        logic signed [31:0] acc3;

        // ========= 2. 输入逻辑：权重 / Ping-Pong Buffer 加载 =========
        logic [3:0] load_cnt;

        logic [7:0] w_byte0, w_byte1, w_byte2, w_byte3;
        assign w_byte0 = stream_data[7:0];
        assign w_byte1 = stream_data[15:8];
        assign w_byte2 = stream_data[23:16];
        assign w_byte3 = stream_data[31:24];

        // 循环变量：统一在块外声明，避免在 always 里声明
        integer r;
        integer idx;
        integer li;
        integer i0, i1, i2, i3;

        // 权重 & Buffer 加载
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                load_cnt <= 4'd0;

                // 权重清零
                for (r = 0; r < 9; r = r + 1) begin
                    weights0[r] <= '0;
                    weights1[r] <= '0;
                    weights2[r] <= '0;
                    weights3[r] <= '0;
                end

                // Ping / Pong Buffer 清零
                for (r = 0; r < 16; r = r + 1) begin
                    buf_A[r] <= '0;
                    buf_B[r] <= '0;
                end
            end else if (stream_valid && ctrl_load_en) begin
                load_cnt <= load_cnt + 4'd1;

                if (ctrl_load_is_wgt) begin
                    // 36 个字节映射到 4x9 权重
                    case (load_cnt)
                        4'd0: begin 
                            weights0[0] <= w_byte0; 
                            weights0[1] <= w_byte1; 
                            weights0[2] <= w_byte2; 
                            weights0[3] <= w_byte3; 
                        end
                        4'd1: begin 
                            weights0[4] <= w_byte0; 
                            weights0[5] <= w_byte1; 
                            weights0[6] <= w_byte2; 
                            weights0[7] <= w_byte3; 
                        end
                        4'd2: begin 
                            weights0[8] <= w_byte0; 
                            weights1[0] <= w_byte1; 
                            weights1[1] <= w_byte2; 
                            weights1[2] <= w_byte3; 
                        end
                        4'd3: begin 
                            weights1[3] <= w_byte0; 
                            weights1[4] <= w_byte1; 
                            weights1[5] <= w_byte2; 
                            weights1[6] <= w_byte3; 
                        end
                        4'd4: begin 
                            weights1[7] <= w_byte0; 
                            weights1[8] <= w_byte1; 
                            weights2[0] <= w_byte2; 
                            weights2[1] <= w_byte3; 
                        end
                        4'd5: begin 
                            weights2[2] <= w_byte0; 
                            weights2[3] <= w_byte1; 
                            weights2[4] <= w_byte2; 
                            weights2[5] <= w_byte3; 
                        end
                        4'd6: begin 
                            weights2[6] <= w_byte0; 
                            weights2[7] <= w_byte1; 
                            weights2[8] <= w_byte2; 
                            weights3[0] <= w_byte3; 
                        end
                        4'd7: begin 
                            weights3[1] <= w_byte0; 
                            weights3[2] <= w_byte1; 
                            weights3[3] <= w_byte2; 
                            weights3[4] <= w_byte3; 
                        end
                        4'd8: begin 
                            weights3[5] <= w_byte0; 
                            weights3[6] <= w_byte1; 
                            weights3[7] <= w_byte2; 
                            weights3[8] <= w_byte3; 
                        end
                        default: ;
                    endcase
                end else begin
                    // Ping-Pong Buffer 填充
                    if (!ctrl_buf_wr_sel) begin
                        // 写 Buffer A
                        buf_A[load_cnt*4 + 0] <= w_byte0;
                        buf_A[load_cnt*4 + 1] <= w_byte1;
                        buf_A[load_cnt*4 + 2] <= w_byte2;
                        buf_A[load_cnt*4 + 3] <= w_byte3;
                    end else begin
                        // 写 Buffer B
                        buf_B[load_cnt*4 + 0] <= w_byte0;
                        buf_B[load_cnt*4 + 1] <= w_byte1;
                        buf_B[load_cnt*4 + 2] <= w_byte2;
                        buf_B[load_cnt*4 + 3] <= w_byte3;
                    end
                end
            end else if (!ctrl_load_en) begin
                load_cnt <= 4'd0;
            end
        end

        // ========= 3. 计算控制逻辑：col_cnt / is_computing / LineBuffer =========
        logic [3:0] col_cnt;
        logic       is_computing;

        // 从 A/B 选 active_buf
        logic signed [7:0] active_buf [0:15];

        always_comb begin
            for (idx = 0; idx < 16; idx = idx + 1) begin
                if (!ctrl_buf_rd_sel)
                    active_buf[idx] = buf_A[idx];
                else
                    active_buf[idx] = buf_B[idx];
            end
        end

        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                is_computing   <= 1'b0;
                stat_calc_done <= 1'b0;
                col_cnt        <= 4'd0;

                for (li = 0; li < 16; li = li + 1) begin
                    line0[li] <= '0;
                    line1[li] <= '0;
                    line2[li] <= '0;
                end
            end else begin
                stat_calc_done <= 1'b0;  // 生成单周期脉冲

                if (ctrl_calc_start) begin
                    is_computing <= 1'b1;
                    col_cnt      <= 4'd0;

                    if (!ctrl_mode_fc) begin
                        // Conv 模式：把 active_buf 当作新的一行推入 LineBuffer
                        for (li = 0; li < 16; li = li + 1) begin
                            line2[li] <= line1[li];
                            line1[li] <= line0[li];
                            line0[li] <= active_buf[li];
                        end
                    end
                end else if (is_computing) begin
                    if (ctrl_mode_fc) begin
                        // FC 模式：固定 1 周期
                        is_computing   <= 1'b0;
                        stat_calc_done <= 1'b1;
                    end else begin
                        // Conv 模式：滑动 14 个位置 (0~13)
                        if (col_cnt == 4'd13) begin
                            is_computing   <= 1'b0;
                            stat_calc_done <= 1'b1;
                        end else begin
                            col_cnt <= col_cnt + 4'd1;
                        end
                    end
                end
            end
        end

        // ========= 4. 公共 3x3 输入窗口 op_a =========
        logic signed [7:0] op_a [0:8];

        always_comb begin
            if (ctrl_mode_fc) begin
                // FC 模式：直接取 active_buf[0..8]
                op_a[0] = active_buf[0];
                op_a[1] = active_buf[1];
                op_a[2] = active_buf[2];
                op_a[3] = active_buf[3];
                op_a[4] = active_buf[4];
                op_a[5] = active_buf[5];
                op_a[6] = active_buf[6];
                op_a[7] = active_buf[7];
                op_a[8] = active_buf[8];
            end else begin
                // Conv 模式：从 line0/1/2 取 3x3 窗口
                op_a[0] = line0[col_cnt+0];
                op_a[1] = line0[col_cnt+1];
                op_a[2] = line0[col_cnt+2];

                op_a[3] = line1[col_cnt+0];
                op_a[4] = line1[col_cnt+1];
                op_a[5] = line1[col_cnt+2];

                op_a[6] = line2[col_cnt+0];
                op_a[7] = line2[col_cnt+1];
                op_a[8] = line2[col_cnt+2];
            end
        end

        // ========= 5. 四个 PE 核：乘加 + ReLU（组合） =========
        logic signed [7:0]  op_b0 [0:8];
        logic signed [7:0]  op_b1 [0:8];
        logic signed [7:0]  op_b2 [0:8];
        logic signed [7:0]  op_b3 [0:8];

        logic signed [19:0] psum0, psum1, psum2, psum3;
        logic [7:0]         relu0, relu1, relu2, relu3;

        // Core 0
        always_comb begin
            for (i0 = 0; i0 < 9; i0 = i0 + 1)
                op_b0[i0] = weights0[i0];

            psum0 = '0;
            for (i0 = 0; i0 < 9; i0 = i0 + 1)
                psum0 = psum0 + op_a[i0] * op_b0[i0];

            if (psum0[19])
                relu0 = 8'd0;
            else if (|psum0[18:8])
                relu0 = 8'd255;
            else
                relu0 = psum0[7:0];
        end

        // Core 1
        always_comb begin
            for (i1 = 0; i1 < 9; i1 = i1 + 1)
                op_b1[i1] = weights1[i1];

            psum1 = '0;
            for (i1 = 0; i1 < 9; i1 = i1 + 1)
                psum1 = psum1 + op_a[i1] * op_b1[i1];

            if (psum1[19])
                relu1 = 8'd0;
            else if (|psum1[18:8])
                relu1 = 8'd255;
            else
                relu1 = psum1[7:0];
        end

        // Core 2
        always_comb begin
            for (i2 = 0; i2 < 9; i2 = i2 + 1)
                op_b2[i2] = weights2[i2];

            psum2 = '0;
            for (i2 = 0; i2 < 9; i2 = i2 + 1)
                psum2 = psum2 + op_a[i2] * op_b2[i2];

            if (psum2[19])
                relu2 = 8'd0;
            else if (|psum2[18:8])
                relu2 = 8'd255;
            else
                relu2 = psum2[7:0];
        end

        // Core 3
        always_comb begin
            for (i3 = 0; i3 < 9; i3 = i3 + 1)
                op_b3[i3] = weights3[i3];

            psum3 = '0;
            for (i3 = 0; i3 < 9; i3 = i3 + 1)
                psum3 = psum3 + op_a[i3] * op_b3[i3];

            if (psum3[19])
                relu3 = 8'd0;
            else if (|psum3[18:8])
                relu3 = 8'd255;
            else
                relu3 = psum3[7:0];
        end

        // ========= 6. 时序：FC 累加 / Conv 写回 =========
        always_ff @(posedge clk_i or negedge rst_ni) begin
            if (!rst_ni) begin
                acc0 <= '0;
                acc1 <= '0;
                acc2 <= '0;
                acc3 <= '0;

                for (r = 0; r < 14; r = r + 1)
                    result_mem[r] <= '0;
            end else begin
                if (ctrl_fc_acc_clear) begin
                    acc0 <= '0;
                    acc1 <= '0;
                    acc2 <= '0;
                    acc3 <= '0;
                end

                if (is_computing) begin
                    if (ctrl_mode_fc) begin
                        // FC 模式：累加 psum
                        acc0 <= acc0 + psum0;
                        acc1 <= acc1 + psum1;
                        acc2 <= acc2 + psum2;
                        acc3 <= acc3 + psum3;
                    end else begin
                        // Conv 模式：写 4 个 ReLU 结果
                        result_mem[col_cnt][7:0]   <= relu0;
                        result_mem[col_cnt][15:8]  <= relu1;
                        result_mem[col_cnt][23:16] <= relu2;
                        result_mem[col_cnt][31:24] <= relu3;
                    end
                end
            end
        end

        // ========= 7. 输出：FC ReLU+饱和 + Conv/FC MUX =========
        logic [7:0] fc_out0, fc_out1, fc_out2, fc_out3;

        always_comb begin
            // 对 FC 累加结果做 ReLU/饱和
            if (acc0[31])         fc_out0 = 8'd0;
            else if (|acc0[30:8]) fc_out0 = 8'd255;
            else                  fc_out0 = acc0[7:0];

            if (acc1[31])         fc_out1 = 8'd0;
            else if (|acc1[30:8]) fc_out1 = 8'd255;
            else                  fc_out1 = acc1[7:0];

            if (acc2[31])         fc_out2 = 8'd0;
            else if (|acc2[30:8]) fc_out2 = 8'd255;
            else                  fc_out2 = acc2[7:0];

            if (acc3[31])         fc_out3 = 8'd0;
            else if (|acc3[30:8]) fc_out3 = 8'd255;
            else                  fc_out3 = acc3[7:0];

            // 输出 MUX
            if (ctrl_mode_fc)
                res_rd_data = {fc_out3, fc_out2, fc_out1, fc_out0};
            else
                res_rd_data = result_mem[res_rd_addr];
        end

    end : block_compute_core

endmodule
