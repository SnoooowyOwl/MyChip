/**
 * @brief accelerator 模块 (v5 - 可综合的多周期 RTL)
 * @details
 * - 移除了 "向量模式" 和 `automatic` 变量。
 * - 采用多周期 (14 周期) 的 COMPUTING 状态。
 * - 使用一个 4 位计数器 (conv_col_cnt) 来跟踪 14 个输出的计算。
 * - 显式地定义了一个 9-PE 乘法阵列和加法器树 (组合逻辑)。
 * - 在 COMPUTING 的每个周期，计算并存储一个结果。
 * - 更新了启动命令以匹配新的约定 (0x0001FFFF, 0x0000FFFF)。
 */
module accelerator (
    input logic clka,       // 时钟
    input logic wea,        // 写使能信号
    input logic ena,        // 整体使能信号
    input logic [10:0] addra,  // 输入地址
    input logic [31:0] dina,   // 输入数据
    output logic [31:0] douta,  // 输出数据
    input logic rst_ni    // 异步复位，低有效
);

    // --- 状态机定义 ---
    localparam [1:0] IDLE      = 2'b00;
    localparam [1:0] COMPUTING = 2'b01;
    localparam [1:0] DONE      = 2'b10;

    // --- 地址映射 ---
    localparam ADDR_CTRL_STATUS    = 11'h000; // BASE + 0
    // Line Buffer (BASE + 4 到 BASE + 48)
    localparam ADDR_LB_0_3         = 11'h004;
    localparam ADDR_LB_4_7         = 11'h008;
    localparam ADDR_LB_8_11        = 11'h00C;
    localparam ADDR_LB_12_15       = 11'h010;
    localparam ADDR_LB_16_19       = 11'h014;
    localparam ADDR_LB_20_23       = 11'h018;
    localparam ADDR_LB_24_27       = 11'h01C;
    localparam ADDR_LB_28_31       = 11'h020;
    localparam ADDR_LB_32_35       = 11'h024;
    localparam ADDR_LB_36_39       = 11'h028;
    localparam ADDR_LB_40_43       = 11'h02C;
    localparam ADDR_LB_44_47       = 11'h030;
    // Weights (BASE + 52 到 BASE + 60)
    localparam ADDR_WEIGHTS_0_3    = 11'h034;
    localparam ADDR_WEIGHTS_4_7    = 11'h038;
    localparam ADDR_WEIGHTS_8      = 11'h03C;
    // Results (BASE + 64 到 BASE + 76)
    localparam ADDR_RESULT_0_3     = 11'h040;
    localparam ADDR_RESULT_4_7     = 11'h044;
    localparam ADDR_RESULT_8_11    = 11'h048;
    localparam ADDR_RESULT_12_13   = 11'h04C;

    // --- 命令码 (已更新) ---
    localparam CMD_START_RELU      = 32'h0001FFFF;
    localparam CMD_START_NO_RELU   = 32'h0000FFFF;
    localparam CMD_RESET_PSUMS     = 32'hFFFFFFFF;
    localparam CMD_SHIFT_LINES     = 32'h00000200;

    // --- 内部存储 ---
    reg signed [7:0] line_buffer [0:2][0:15];
    reg [7:0]        weights [0:8];
    reg signed [31:0] psum_results [0:13];  // 存储高精度Psum
    reg [7:0]        final_results [0:13]; // 存储后处理的UInt8

    // --- 状态机和控制寄存器 ---
    reg [1:0]    state;
    reg [31:0]   status_reg;
    reg [31:0]   douta_reg;
    reg          relu_en_reg;  // 存储计算期间的ReLU选择
    reg [3:0]    conv_col_cnt; // 卷积列计数器 (0 to 13)

    // --- 循环变量 ---
    integer i, j;
    genvar k;

    // --- 输出逻辑 ---
    assign douta = douta_reg;

    // --- 1. 组合逻辑数据通路 (9-PE 阵列 + 加法器树) ---
    // 这是硬件的核心：9个乘法器和一个加法器树
    // 它的输入是 *寄存器* (line_buffer, weights, conv_col_cnt)
    // 它的输出是 *线网* (next_psum, next_final_result)

    wire signed [16:0] prods [0:8];         // 9 个 PE 的乘积
    wire signed [8:0]  temp_weights [0:8];  // 9 个 PE 的(有符号)权重
    wire signed [31:0] next_psum;           // 加法器树的输出
    wire signed [31:0] relu_val;            // ReLU 的输出
    wire [7:0]        next_final_result;   // 后处理的最终输出

    // 1a. 9-PE 乘法阵列
    generate
        for (k = 0; k < 9; k = k + 1) begin : gen_pe_mac
            // 将 uint8 权重转换为 sint9
            assign temp_weights[k] = {1'b0, weights[k]};

            // 乘法器 (k/3 = row, k%3 = col)
            // line_buffer[row][col_base + col_offset]
            assign prods[k] = line_buffer[k/3][conv_col_cnt + (k%3)] * temp_weights[k];
        end
    endgenerate

    // 1b. 加法器树 (将 9 个乘积相加)
    assign next_psum = prods[0] + prods[1] + prods[2] +
                       prods[3] + prods[4] + prods[5] +
                       prods[6] + prods[7] + prods[8];

    // 1c. 后处理 (ReLU + 饱和/截断到 UInt8)
    assign relu_val = (relu_en_reg && next_psum[31]) ? 32'b0 : next_psum;

    assign next_final_result = (relu_val > 32'd255) ? 8'd255 :   // 饱和 (上溢)
                               (relu_val < 32'd0)   ? 8'd0 :     // 饱和 (下溢)
                               relu_val[7:0];                   // 截断


    // --- 2. 时序逻辑 (状态机、控制、寄存器写入) ---
    always_ff @(posedge clka or negedge rst_ni) begin
        if (!rst_ni) begin
            // --- 异步复位 ---
            state        <= IDLE;
            status_reg   <= 32'h0;
            douta_reg    <= 32'h0;
            relu_en_reg  <= 1'b0;
            conv_col_cnt <= 4'b0;

            for (i = 0; i < 3; i = i + 1) begin
                for (j = 0; j < 16; j = j + 1) begin
                    line_buffer[i][j] <= 8'b0;
                end
            end
            for (i = 0; i < 9; i = i + 1) begin
                weights[i] <= 8'b0;
            end
            for (i = 0; i < 14; i = i + 1) begin
                psum_results[i]  <= 32'b0;
                final_results[i] <= 8'b0;
            end
        end
        else if (ena) begin

            // --- 2a. 写操作 (最高优先级) ---
            if (wea) begin
                case (addra)
                    // BASE + 0: 控制寄存器
                    ADDR_CTRL_STATUS: begin
                        if (dina == CMD_RESET_PSUMS) begin
                            for (i = 0; i < 14; i = i + 1) begin
                                psum_results[i]  <= 32'b0;
                                final_results[i] <= 8'b0;
                            end
                            state      <= IDLE;
                            status_reg <= 32'h0;
                        end
                        else if (dina == CMD_START_RELU) begin
                            // 开始 (带 ReLU)
                            relu_en_reg  <= 1'b1;
                            conv_col_cnt <= 4'b0; // 重置计数器
                            status_reg   <= 32'h0; // 标记为 "Busy"
                            state        <= COMPUTING;
                        end
                        else if (dina == CMD_START_NO_RELU) begin
                            // 开始 (不带 ReLU)
                            relu_en_reg  <= 1'b0;
                            conv_col_cnt <= 4'b0; // 重置计数器
                            status_reg   <= 32'h0; // 标记为 "Busy"
                            state        <= COMPUTING;
                        end
                        else if (dina == CMD_SHIFT_LINES) begin
                            // 行移位命令
                            for (i = 0; i < 16; i = i + 1) begin
                                line_buffer[2][i] <= line_buffer[1][i];
                                line_buffer[1][i] <= line_buffer[0][i];
                            end
                        end
                    end

                    // --- Line Buffer 写入 (12个地址) ---
                    ADDR_LB_0_3:   begin line_buffer[0][0]<=dina[31:24]; line_buffer[0][1]<=dina[23:16]; line_buffer[0][2]<=dina[15:8]; line_buffer[0][3]<=dina[7:0]; end
                    ADDR_LB_4_7:   begin line_buffer[0][4]<=dina[31:24]; line_buffer[0][5]<=dina[23:16]; line_buffer[0][6]<=dina[15:8]; line_buffer[0][7]<=dina[7:0]; end
                    ADDR_LB_8_11:  begin line_buffer[0][8]<=dina[31:24]; line_buffer[0][9]<=dina[23:16]; line_buffer[0][10]<=dina[15:8]; line_buffer[0][11]<=dina[7:0]; end
                    ADDR_LB_12_15: begin line_buffer[0][12]<=dina[31:24]; line_buffer[0][13]<=dina[23:16]; line_buffer[0][14]<=dina[15:8]; line_buffer[0][15]<=dina[7:0]; end
                    ADDR_LB_16_19: begin line_buffer[1][0]<=dina[31:24]; line_buffer[1][1]<=dina[23:16]; line_buffer[1][2]<=dina[15:8]; line_buffer[1][3]<=dina[7:0]; end
                    ADDR_LB_20_23: begin line_buffer[1][4]<=dina[31:24]; line_buffer[1][5]<=dina[23:16]; line_buffer[1][6]<=dina[15:8]; line_buffer[1][7]<=dina[7:0]; end
                    ADDR_LB_24_27: begin line_buffer[1][8]<=dina[31:24]; line_buffer[1][9]<=dina[23:16]; line_buffer[1][10]<=dina[15:8]; line_buffer[1][11]<=dina[7:0]; end
                    ADDR_LB_28_31: begin line_buffer[1][12]<=dina[31:24]; line_buffer[1][13]<=dina[23:16]; line_buffer[1][14]<=dina[15:8]; line_buffer[1][15]<=dina[7:0]; end
                    ADDR_LB_32_35: begin line_buffer[2][0]<=dina[31:24]; line_buffer[2][1]<=dina[23:16]; line_buffer[2][2]<=dina[15:8]; line_buffer[2][3]<=dina[7:0]; end
                    ADDR_LB_36_39: begin line_buffer[2][4]<=dina[31:24]; line_buffer[2][5]<=dina[23:16]; line_buffer[2][6]<=dina[15:8]; line_buffer[2][7]<=dina[7:0]; end
                    ADDR_LB_40_43: begin line_buffer[2][8]<=dina[31:24]; line_buffer[2][9]<=dina[23:16]; line_buffer[2][10]<=dina[15:8]; line_buffer[2][11]<=dina[7:0]; end
                    ADDR_LB_44_47: begin line_buffer[2][12]<=dina[31:24]; line_buffer[2][13]<=dina[23:16]; line_buffer[2][14]<=dina[15:8]; line_buffer[2][15]<=dina[7:0]; end

                    // --- Weights 写入 (3个地址) ---
                    ADDR_WEIGHTS_0_3: begin weights[0]<=dina[31:24]; weights[1]<=dina[23:16]; weights[2]<=dina[15:8]; weights[3]<=dina[7:0]; end
                    ADDR_WEIGHTS_4_7: begin weights[4]<=dina[31:24]; weights[5]<=dina[23:16]; weights[6]<=dina[15:8]; weights[7]<=dina[7:0]; end
                    ADDR_WEIGHTS_8:   begin weights[8]<=dina[31:24]; end

                    default: begin
                    end
                endcase
            end // if (wea)

            // --- 2b. 读操作 和 状态机 (非写) ---
            else begin // (ena && !wea)

                // 读操作 (组合逻辑连接到 douta_reg)
                case (addra)
                    ADDR_CTRL_STATUS:  douta_reg <= status_reg;
                    ADDR_RESULT_0_3:   douta_reg <= {final_results[0], final_results[1], final_results[2], final_results[3]};
                    ADDR_RESULT_4_7:   douta_reg <= {final_results[4], final_results[5], final_results[6], final_results[7]};
                    ADDR_RESULT_8_11:  douta_reg <= {final_results[8], final_results[9], final_results[10], final_results[11]};
                    ADDR_RESULT_12_13: douta_reg <= {final_results[12], final_results[13], 16'h0000};
                    default:           douta_reg <= 32'h0;
                endcase

                // 状态机更新
                case (state)
                    IDLE: begin
                        // 保持IDLE, 等待 'START' 写入
                    end

                    COMPUTING: begin
                        // 组合逻辑数据通路 (在 always 块外部) 正在
                        // 基于 *当前* 的 conv_col_cnt 计算 next_psum 和 next_final_result

                        // 在时钟沿，将计算结果锁存到 *当前* 计数器索引的 RAM 中
                        psum_results[conv_col_cnt]  <= next_psum;
                        final_results[conv_col_cnt] <= next_final_result;

                        // 推进到下一个计算
                        conv_col_cnt <= conv_col_cnt + 1;

                        // 检查是否完成 (计算 0 到 13)
                        if (conv_col_cnt == 4'd13) begin
                            state      <= DONE;
                            status_reg <= 32'h00000001; // 设置 "完成" 标志
                        end
                    end

                    DONE: begin
                        // 保持DONE, 等待 'RESET' 或 'START' 写入 (在 'wea' 逻辑中处理)
                    end
                endcase
            end // else (!wea)

        end // if (ena)
    end // always_ff

endmodule
