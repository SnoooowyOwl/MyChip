/**
 * @file accelerator.sv
 * @brief 卷积计算加速器模块
 *
 * * 修改说明:
 * - 严格遵循 accelerator_2 的 RAM-like 读写时序结构：if (ena && wea) Write else Read。
 * - 读操作：严格按照协议，只响应状态寄存器和结果寄存器的读取，其余地址（包括 BASE+4）均返回 0。
 */
module accelerator (
    // ================= Global =================
    input  logic        clka,
    input  logic        rst_ni,

    // ================= Slave Interface (CPU writes here) =================
    input  logic        wea,        // Write Enable
    input  logic        ena,        // Chip Enable
    input  logic [10:0] addra,      // Address (Byte offset from axi2mem)
    input  logic [31:0] dina,       // Write Data
    output logic [31:0] douta,      // Read Data (NPU status or result)

    // ================= Master Interface (NPU reads SRAM/DDR) =================
    // Read Address Channel
    output logic [31:0] m_axi_araddr,
    output logic [7:0]  m_axi_arlen,
    output logic [2:0]  m_axi_arsize,
    output logic [1:0]  m_axi_arburst,
    output logic        m_axi_arvalid,
    input  logic        m_axi_arready,

    // Read Data Channel
    input  logic [31:0] m_axi_rdata,
    input  logic [1:0]  m_axi_rresp,
    input  logic        m_axi_rlast,
    input  logic        m_axi_rvalid,
    output logic        m_axi_rready
);

    // =================================================================
    // --- 1. 常量定义 (地址/命令) ---
    // =================================================================

    // --- Slave 地址映射 ---
    localparam ADDR_CTRL_STATUS    = 11'h000; // BASE + 0 (控制/状态)
    localparam ADDR_SRC_ADDR       = 11'h004; // BASE + 4 (DMA读取地址) - 只写
    
    localparam ADDR_WEIGHTS_0_3    = 11'h034; // BASE + 52
    localparam ADDR_WEIGHTS_4_7    = 11'h038; // BASE + 56
    localparam ADDR_WEIGHTS_8      = 11'h03C; // BASE + 60

    localparam ADDR_RESULT_0_3     = 11'h040; // BASE + 64 (R0-R3)
    localparam ADDR_RESULT_4_7     = 11'h044; // BASE + 68
    localparam ADDR_RESULT_8_11    = 11'h048; // BASE + 72
    localparam ADDR_RESULT_12_13   = 11'h04C; // BASE + 76

    // --- 命令码 ---
    localparam CMD_START_RELU      = 32'h0001FFFF;
    localparam CMD_START_NO_RELU   = 32'h0000FFFF;
    localparam CMD_RESET_PSUMS     = 32'h0FFFFFFF; // PE部分和清零
    localparam CMD_GLOBAL_RESET    = 32'hFFFFFFFF; // 全局清零
    localparam CMD_SHIFT_LINES     = 32'h00000200; // Line Buffer 下移

    // --- 状态标志 ---
    localparam STATUS_DONE         = 32'h00000001; // 计算完成
    localparam STATUS_BUSY         = 32'h00000000; // 计算未完成

    // =================================================================
    // --- 2. 内部存储和状态寄存器 ---
    // =================================================================

    // --- 数据存储 ---
    reg signed [7:0] line_buffer [0:2][0:15]; 
    reg signed [7:0] prefetch_buffer [0:15];
    reg [7:0]        weights [0:8];
    reg [7:0]        final_results [0:13];

    // --- 寄存器 ---
    reg [31:0] reg_src_addr;       // BASE+4
    reg [31:0] douta_reg;          // Read Output Register
    reg [31:0] status_reg;         // BASE+0

    // --- 状态机 ---
    typedef enum logic [1:0] { IDLE, COMPUTING, DONE } comp_state_t;
    reg [1:0] comp_state;

    reg          relu_en_reg;
    reg [3:0]    conv_col_cnt;

    typedef enum logic [1:0] { DMA_IDLE, DMA_SEND_ADDR, DMA_READ_DATA } dma_state_t;
    reg [1:0] dma_state;

    reg dma_addr_valid;
    reg [31:0] dma_read_addr;
    reg [2:0]  dma_word_cnt;

    // =================================================================
    // --- 3. 组合逻辑 (计算核心 & AXI) ---
    // =================================================================

    // --- 3a. PE 阵列 ---
    wire signed [16:0] prods [0:8];         
    wire signed [8:0]  temp_weights [0:8];  
    wire signed [31:0] next_psum;           
    wire signed [31:0] relu_val;            
    wire [7:0]        next_final_result;   

    genvar k;
    generate
        for (k = 0; k < 9; k = k + 1) begin : gen_pe_mac
            assign temp_weights[k] = {1'b0, weights[k]}; 
            assign prods[k] = line_buffer[k/3][conv_col_cnt + (k%3)] * temp_weights[k];
        end
    endgenerate

    assign next_psum = prods[0] + prods[1] + prods[2] +
                       prods[3] + prods[4] + prods[5] +
                       prods[6] + prods[7] + prods[8];

    assign relu_val = (relu_en_reg && next_psum[31]) ? 32'b0 : next_psum;

    assign next_final_result = (relu_val > 32'd255) ? 8'd255 :   
                               (relu_val < 32'd0)   ? 8'd0 :     
                               relu_val[7:0];                   

    // --- 3b. AXI Master ---
    assign m_axi_araddr  = dma_read_addr;
    assign m_axi_arlen   = 8'd3;    // 4 beats
    assign m_axi_arsize  = 3'b010;  // 32-bit
    assign m_axi_arburst = 2'b01;   // INCR
    
    always_comb begin
        m_axi_arvalid = 1'b0;
        m_axi_rready  = 1'b0;
        
        case (dma_state)
            DMA_IDLE:      m_axi_arvalid = 1'b0;
            DMA_SEND_ADDR: m_axi_arvalid = 1'b1;
            DMA_READ_DATA: m_axi_rready  = 1'b1;
            default: ;
        endcase
    end

    // 输出连接
    assign douta = douta_reg;

    // =================================================================
    // --- 4. 时序逻辑 (核心) ---
    // =================================================================

    integer i, j; 

    always_ff @(posedge clka or negedge rst_ni) begin
        if (!rst_ni) begin
            // --- 复位 ---
            comp_state     <= IDLE;
            dma_state      <= DMA_IDLE;
            status_reg     <= STATUS_BUSY;
            relu_en_reg    <= 1'b0;
            conv_col_cnt   <= 4'b0;
            reg_src_addr   <= 32'h0;
            dma_addr_valid <= 1'b0; 
            dma_read_addr  <= 32'h0;
            dma_word_cnt   <= 3'b0;
            douta_reg      <= 32'h0;

            for (i = 0; i < 3; i = i + 1) 
                for (j = 0; j < 16; j = j + 1) line_buffer[i][j] <= 8'b0;
            for (j = 0; j < 16; j = j + 1) prefetch_buffer[j] <= 8'b0;
            for (i = 0; i < 9; i = i + 1) weights[i] <= 8'b0;
            for (i = 0; i < 14; i = i + 1) final_results[i] <= 8'b0;
        end 
        else begin
            
            // --- 4a. Slave 读写逻辑 (高优先级结构) ---
            // 严格按照要求：if (ena && wea) 写; else 读;
            
            if (ena ) begin
                if(wea) begin
                    // ====== 写操作 ======
                    case (addra)
                        ADDR_CTRL_STATUS: begin
                            if (dina == CMD_GLOBAL_RESET) begin
                                comp_state     <= IDLE;
                                dma_state      <= DMA_IDLE;
                                status_reg     <= STATUS_BUSY;
                                dma_addr_valid <= 1'b0; 
                                for (i = 0; i < 3; i = i + 1) 
                                    for (j = 0; j < 16; j = j + 1) line_buffer[i][j] <= 8'b0;
                                for (j = 0; j < 16; j = j + 1) prefetch_buffer[j] <= 8'b0;
                                for (i = 0; i < 14; i = i + 1) final_results[i] <= 8'b0;
                            end
                            else if (dina == CMD_RESET_PSUMS) begin
                                status_reg     <= STATUS_BUSY;
                                comp_state     <= IDLE;
                                for (i = 0; i < 14; i = i + 1) final_results[i] <= 8'b0;
                            end
                            else if (dina == CMD_START_RELU || dina == CMD_START_NO_RELU) begin
                                relu_en_reg    <= (dina == CMD_START_RELU);
                                conv_col_cnt   <= 4'b0; 
                                status_reg     <= STATUS_BUSY;
                                comp_state     <= COMPUTING;
                            end
                            else if (dina == CMD_SHIFT_LINES) begin
                                for (i = 0; i < 16; i = i + 1) begin
                                    line_buffer[2][i] <= line_buffer[1][i];
                                    line_buffer[1][i] <= line_buffer[0][i];
                                    line_buffer[0][i] <= prefetch_buffer[i];
                                end
                            end
                        end
                        ADDR_SRC_ADDR: begin
                            reg_src_addr   <= dina; 
                            dma_addr_valid <= 1'b1; // 触发 DMA
                        end

                        ADDR_WEIGHTS_0_3: begin weights[0]<=dina[31:24]; weights[1]<=dina[23:16]; weights[2]<=dina[15:8]; weights[3]<=dina[7:0]; end
                        ADDR_WEIGHTS_4_7: begin weights[4]<=dina[31:24]; weights[5]<=dina[23:16]; weights[6]<=dina[15:8]; weights[7]<=dina[7:0]; end
                        ADDR_WEIGHTS_8:   begin weights[8]<=dina[31:24]; end
                        default: ;
                    endcase
                end 

                else begin
                    // ====== 读操作 (else 分支) ======
                    // 只要不是写，就执行读。保证 1 cycle latency。
                    case (addra)
                        ADDR_CTRL_STATUS:  douta_reg <= status_reg; 

                        ADDR_RESULT_0_3:   douta_reg <= {final_results[3], final_results[2], final_results[1], final_results[0]};
                        ADDR_RESULT_4_7:   douta_reg <= {final_results[7], final_results[6], final_results[5], final_results[4]};
                        ADDR_RESULT_8_11:  douta_reg <= {final_results[11], final_results[10], final_results[9], final_results[8]};
                        ADDR_RESULT_12_13: douta_reg <= {final_results[13], final_results[12], 16'h0000};

                        default:           douta_reg <= 32'h0; // 包含 ADDR_SRC_ADDR 等所有未定义读取的地址
                    endcase
                end
            end

            // --- 4b. 独立运行的计算状态机 ---
            case (comp_state)
                IDLE: begin end
                COMPUTING: begin
                    final_results[conv_col_cnt] <= next_final_result;
                    if (conv_col_cnt == 4'd13) begin
                        comp_state <= DONE;
                        status_reg <= STATUS_DONE; 
                    end else begin
                        conv_col_cnt <= conv_col_cnt + 1;
                    end
                end
                DONE: begin end
            endcase

            // --- 4c. 独立运行的 DMA 状态机 ---
            case (dma_state)
                DMA_IDLE: begin
                    dma_word_cnt <= 3'b0;
                    if (dma_addr_valid) begin 
                        dma_state     <= DMA_SEND_ADDR;
                        dma_read_addr <= reg_src_addr; 
                        dma_addr_valid <= 1'b0;        
                    end
                end
                DMA_SEND_ADDR: begin
                    if (m_axi_arvalid && m_axi_arready) begin
                        dma_state <= DMA_READ_DATA;
                    end
                end
                DMA_READ_DATA: begin
                    if (m_axi_rvalid && m_axi_rready) begin
                        prefetch_buffer[dma_word_cnt*4 + 3] <= $signed(m_axi_rdata[31:24]);
                        prefetch_buffer[dma_word_cnt*4 + 2] <= $signed(m_axi_rdata[23:16]);
                        prefetch_buffer[dma_word_cnt*4 + 1] <= $signed(m_axi_rdata[15:8]);
                        prefetch_buffer[dma_word_cnt*4 + 0] <= $signed(m_axi_rdata[7:0]);
                        
                        dma_word_cnt <= dma_word_cnt + 1;

                        if (m_axi_rlast) begin
                            if (dma_addr_valid) begin
                                dma_state <= DMA_SEND_ADDR;
                                dma_read_addr <= reg_src_addr; 
                                dma_addr_valid <= 1'b0;        
                            end else begin
                                dma_state <= DMA_IDLE; 
                            end
                        end
                    end
                end
                default: dma_state <= DMA_IDLE;
            endcase

        end 
    end 
endmodule