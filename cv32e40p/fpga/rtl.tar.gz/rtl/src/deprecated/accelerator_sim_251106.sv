module accelerator (
    input         clka,
    input         wea,
    input         ena,
    input [10:0] addra, // 关键: 这是 [12:2] 转换后的 11 位地址
    input [31:0] dina,
    output [31:0] douta,
    input         rst_ni
);

    // --- 核心参数 ---
    parameter PE_COUNT     = 9;  // 3x3 卷积核
    parameter LINE_WIDTH   = 16; // 1 行 16 个像素
    parameter OUTPUT_WIDTH = 14; // 16 - 3 + 1 = 14 次卷积

    // --- 状态机定义 ---
    parameter [1:0] IDLE      = 2'b00;
    parameter [1:0] COMPUTING = 2'b01; // 14个周期的自主计算
    parameter [1:0] DONE      = 2'b10;

    // --- 内部存储 ---
    reg [7:0]         pe_weight [0:PE_COUNT-1];
    reg signed [7:0]  line_buf_0 [0:LINE_WIDTH-1];
    reg signed [7:0]  line_buf_1 [0:LINE_WIDTH-1];
    reg signed [7:0]  line_buf_2 [0:LINE_WIDTH-1];
    reg signed [31:0] output_buf [0:OUTPUT_WIDTH-1];
    
    // --- 控制/状态 ---
    reg [1:0]   state;
    reg [31:0]  status_reg;
    reg [31:0]  douta_reg;
    reg [3:0]   col_ptr; // 0 到 13

    // --- 滑动窗口 (Sliding Window) 组合逻辑 ---
    wire signed [7:0] patch_data [0:PE_COUNT-1];
    assign patch_data[0] = line_buf_0[col_ptr + 0];
    assign patch_data[1] = line_buf_0[col_ptr + 1];
    assign patch_data[2] = line_buf_0[col_ptr + 2];
    assign patch_data[3] = line_buf_1[col_ptr + 0];
    assign patch_data[4] = line_buf_1[col_ptr + 1];
    assign patch_data[5] = line_buf_1[col_ptr + 2];
    assign patch_data[6] = line_buf_2[col_ptr + 0];
    assign patch_data[7] = line_buf_2[col_ptr + 1];
    assign patch_data[8] = line_buf_2[col_ptr + 2];

    // --- 计算核心 (9-PEs + 加法树) ---
    wire signed [16:0] prod [0:PE_COUNT-1];
    genvar i_gen;
    generate
        for (i_gen = 0; i_gen < PE_COUNT; i_gen = i_gen + 1) begin : gen_mult
            wire signed [8:0] temp_weight;
            assign temp_weight = {1'b0, pe_weight[i_gen]};
            assign prod[i_gen] = patch_data[i_gen] * temp_weight;
        end
    endgenerate

    // 组合逻辑加法树 (23位修正版)
    wire signed [31:0] conv_sum;
    wire signed [19:0] stage1_sum [0:2];
    wire signed [22:0] stage2_sum;

    assign stage1_sum[0] = {{3{prod[0][16]}}, prod[0]} + {{3{prod[1][16]}}, prod[1]} + {{3{prod[2][16]}}, prod[2]};
    assign stage1_sum[1] = {{3{prod[3][16]}}, prod[3]} + {{3{prod[4][16]}}, prod[4]} + {{3{prod[5][16]}}, prod[5]};
    assign stage1_sum[2] = {{3{prod[6][16]}}, prod[6]} + {{3{prod[7][16]}}, prod[7]} + {{3{prod[8][16]}}, prod[8]};
    assign stage2_sum     = {{3{stage1_sum[0][19]}}, stage1_sum[0]} + 
                            {{3{stage1_sum[1][19]}}, stage1_sum[1]} + 
                            {{3{stage1_sum[2][19]}}, stage1_sum[2]};
    assign conv_sum       = {{9{stage2_sum[22]}}, stage2_sum};

    // --- 逻辑实现 ---
    assign douta = douta_reg;
    integer i;

    // --- 同步逻辑块 ---
    always @(posedge clka or negedge rst_ni) begin
        if (!rst_ni) begin
            // --- 异步复位 ---
            state <= IDLE;
            status_reg <= 32'h0;
            douta_reg  <= 32'h0;
            col_ptr    <= 4'b0;
            
            for (i = 0; i < PE_COUNT; i = i + 1) begin
                pe_weight[i] <= 8'b0;
            end
            for (i = 0; i < LINE_WIDTH; i = i + 1) begin
                line_buf_0[i] <= 8'b0;
                line_buf_1[i] <= 8'b0;
                line_buf_2[i] <= 8'b0;
            end
            for (i = 0; i < OUTPUT_WIDTH; i = i + 1) begin
                output_buf[i] <= 32'b0;
            end
        end 
        else if (ena) begin
            
            // 🌟 修复 Latch 隐患: 明确 'douta_reg' 的默认行为 🌟
            douta_reg <= douta_reg; // 默认保持上周期的值

            // --- 1. 写操作 (最高优先级) ---
            if (wea) begin
                // 写入时，状态机保持/重置为 IDLE
                state <= IDLE;
                status_reg <= 32'h0;

                // --- 🌟 V3.1 修正版: 连续地址映射 🌟 ---
                case (addra)
                    // (CPU 访问 0x7000_0000)
                    11'h000: begin // 控制寄存器
                        if (dina == 32'h0000FFFF) begin
                            state <= COMPUTING; // START!
                            col_ptr <= 4'b0; 
                        end 
                        else if (dina == 32'hFFFFFFFF) begin
                            // RESET (清空输出缓存, 准备多通道累加)
                            for (i = 0; i < OUTPUT_WIDTH; i = i + 1) begin
                                output_buf[i] <= 32'b0;
                            end
                            state <= IDLE;
                        end
                    end
                    
                    // --- 写入 3x3 权重 ---
                    // (CPU 访问 0x7000_0004)
                    11'h001: begin // W[0-3]
                        pe_weight[0] <= dina[31:24];
                        pe_weight[1] <= dina[23:16];
                        pe_weight[2] <= dina[15:8];
                        pe_weight[3] <= dina[7:0];
                    end
                    // (CPU 访问 0x7000_0008)
                    11'h002: begin // W[4-7]
                        pe_weight[4] <= dina[31:24];
                        pe_weight[5] <= dina[23:16];
                        pe_weight[6] <= dina[15:8];
                        pe_weight[7] <= dina[7:0];
                    end
                    // (CPU 访问 0x7000_000C)
                    11'h003: begin // W[8]
                        pe_weight[8] <= dina[31:24];
                    end

                    // --- 写入行缓存 0 (16 个元素) ---
                    // (CPU 访问 0x7000_0010)
                    11'h004: begin // L0[0-3]
                        line_buf_0[0] <= dina[31:24];
                        line_buf_0[1] <= dina[23:16];
                        line_buf_0[2] <= dina[15:8];
                        line_buf_0[3] <= dina[7:0];
                    end
                    // (CPU 访问 0x7000_0014)
                    11'h005: begin // L0[4-7]
                        line_buf_0[4] <= dina[31:24];
                        line_buf_0[5] <= dina[23:16];
                        line_buf_0[6] <= dina[15:8];
                        line_buf_0[7] <= dina[7:0];
                    end
                    // (CPU 访问 0x7000_0018)
                    11'h006: begin // L0[8-11]
                        line_buf_0[8] <= dina[31:24];
                        line_buf_0[9] <= dina[23:16];
                        line_buf_0[10] <= dina[15:8];
                        line_buf_0[11] <= dina[7:0];
                    end
                    // (CPU 访问 0x7000_001C)
                    11'h007: begin // L0[12-15]
                        line_buf_0[12] <= dina[31:24];
                        line_buf_0[13] <= dina[23:16];
                        line_buf_0[14] <= dina[15:8];
                        line_buf_0[15] <= dina[7:0];
                    end

                    // --- 写入行缓存 1 (16 个元素) ---
                    // (CPU 访问 0x7000_0020)
                    11'h008: begin line_buf_1[0] <= dina[31:24]; line_buf_1[1] <= dina[23:16]; line_buf_1[2] <= dina[15:8]; line_buf_1[3] <= dina[7:0]; end
                    // (CPU 访问 0x7000_0024)
                    11'h009: begin line_buf_1[4] <= dina[31:24]; line_buf_1[5] <= dina[23:16]; line_buf_1[6] <= dina[15:8]; line_buf_1[7] <= dina[7:0]; end
                    // (CPU 访问 0x7000_0028)
                    11'h00A: begin line_buf_1[8] <= dina[31:24]; line_buf_1[9] <= dina[23:16]; line_buf_1[10] <= dina[15:8]; line_buf_1[11] <= dina[7:0]; end
                    // (CPU 访问 0x7000_002C)
                    11'h00B: begin line_buf_1[12] <= dina[31:24]; line_buf_1[13] <= dina[23:16]; line_buf_1[14] <= dina[15:8]; line_buf_1[15] <= dina[7:0]; end

                    // --- 写入行缓存 2 (16 个元素) ---
                    // (CPU 访问 0x7000_0030)
                    11'h00C: begin line_buf_2[0] <= dina[31:24]; line_buf_2[1] <= dina[23:16]; line_buf_2[2] <= dina[15:8]; line_buf_2[3] <= dina[7:0]; end
                    // (CPU 访问 0x7000_0034)
                    11'h00D: begin line_buf_2[4] <= dina[31:24]; line_buf_2[5] <= dina[23:16]; line_buf_2[6] <= dina[15:8]; line_buf_2[7] <= dina[7:0]; end
                    // (CPU 访问 0x7000_0038)
                    11'h00E: begin line_buf_2[8] <= dina[31:24]; line_buf_2[9] <= dina[23:16]; line_buf_2[10] <= dina[15:8]; line_buf_2[11] <= dina[7:0]; end
                    // (CPU 访问 0x7000_003C)
                    11'h00F: begin line_buf_2[12] <= dina[31:24]; line_buf_2[13] <= dina[23:16]; line_buf_2[14] <= dina[15:8]; line_buf_2[15] <= dina[7:0]; end

                    default: begin 
                    end
                endcase
            end // if (wea)

            // --- 2. 读操作 和 状态机 ---
            else begin // (ena && !wea)

                // --- 2a. 读操作 ---
                // (默认值 douta_reg <= douta_reg 已在顶部设置)
                case (addra)
                    // (CPU 访问 0x7000_0000)
                    11'h000: douta_reg <= status_reg;
                    
                    // --- 读取 14 个输出结果 (带 ReLU) ---
                    // (CPU 访问 0x7000_0040)
                    11'h010: douta_reg <= (output_buf[0][31]) ? 32'h0 : output_buf[0];
                    // (CPU 访问 0x7000_0044)
                    11'h011: douta_reg <= (output_buf[1][31]) ? 32'h0 : output_buf[1];
                    // (CPU 访问 0x7000_0048)
                    11'h012: douta_reg <= (output_buf[2][31]) ? 32'h0 : output_buf[2];
                    // (CPU 访问 0x7000_004C)
                    11'h013: douta_reg <= (output_buf[3][31]) ? 32'h0 : output_buf[3];
                    // ... (依此类推) ...
                    // (CPU 访问 0x7000_0074)
                    11'h01D: douta_reg <= (output_buf[13][31]) ? 32'h0 : output_buf[13];
                    
                    // (为简洁, 0x014-0x01C 省略, 逻辑同上)
                    
                    default: douta_reg <= 32'h0; // 读取未定义地址返回 0
                endcase

                // --- 2b. 状态机 (内部状态更新) ---
                case (state)
                    IDLE: begin
                        // 保持IDLE
                        status_reg <= 32'h0; // 确保 'DONE' 标志在 IDLE 时为低
                    end
                    
                    COMPUTING: begin
                        // V3.1 自主计算状态
                        
                        // 累加结果 (实现多通道)
                        // conv_sum 是 *当前* 指针的组合逻辑结果
                        output_buf[col_ptr] <= output_buf[col_ptr] + conv_sum;
                        
                        // 移动指针/检查结束
                        if (col_ptr == (OUTPUT_WIDTH - 1)) begin // (col_ptr == 13)
                            // 一行计算完毕!
                            state      <= DONE;
                            status_reg <= 32'h00000001; // 升起 "完成" 标志
                            col_ptr    <= 4'b0; 
                        end
                        else begin
                            // 移动到下一个窗口
                            col_ptr <= col_ptr + 1;
                            state <= COMPUTING; // 保持计算
                        end
                    end
                    
                    DONE: begin
                        // 保持DONE, 等待 CPU 读取结果
                        status_reg <= 32'h00000001;
                    end
                endcase
            end // else (!wea)

        end // if (ena)
    end // always

endmodule