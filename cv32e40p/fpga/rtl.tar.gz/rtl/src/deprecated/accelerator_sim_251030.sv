//accelerator.sv
/*
module accelerator (
    input logic clka,
    input logic wea,
    input logic ena,
    input logic [10:0] addra,
    input logic [31:0] dina,
    output logic [31:0] douta,
    input logic rst_ni // 异步复位，低有效
);

    // 内部寄存器
    logic [31:0] operand1;
    logic [31:0] operand2;
    
    // 地址映射
    localparam ADDR_OPERAND1 = 0;  // 操作数1的地址
    localparam ADDR_OPERAND2 = 1;  // 操作数2的地址
    localparam ADDR_RESULT   = 2;  // 结果地址
    
    // 写入和计算逻辑
    always_ff @(posedge clka or negedge rst_ni) begin
        if (!rst_ni) begin
            operand1 <= 32'b0;
            operand2 <= 32'b0;
        end else begin
            // 写入操作数
            if (ena && wea) begin
                case (addra)
                    ADDR_OPERAND1: operand1 <= dina;
                    ADDR_OPERAND2: operand2 <= dina;
                endcase
            end
            
            // 执行加法计算（组合逻辑，但用寄存器存储结果）
            if (ena && !wea) begin
                case (addra)
                    ADDR_RESULT: douta <= operand1 + operand2;
                endcase
            end
        end
    end

endmodule

*/

module accelerator (
    input        clka,
    input        wea,
    input        ena,
    input [10:0] addra,
    input [31:0] dina,
    output [31:0] douta,
    input        rst_ni
);

    parameter PE_COUNT = 10;

    // --- 状态机定义 ---
    parameter [1:0] IDLE      = 2'b00;
    parameter [1:0] COMPUTING = 2'b01;
    parameter [1:0] DONE      = 2'b10;

    // --- 内部存储 ---
    reg signed [7:0]   pe_data   [0:PE_COUNT-1];
    reg [7:0]          pe_weight [0:PE_COUNT-1];
    reg signed [31:0]  pe_psum   [0:PE_COUNT-1];
    
    // --- 状态机和控制/状态寄存器 ---
    reg [1:0]    state;
    reg [31:0]   status_reg;
    reg [31:0]   douta_reg;

    // --- 乘法器组合逻辑 ---
    wire signed [16:0] prod [0:PE_COUNT-1];
    genvar i_gen;
    generate
        for (i_gen = 0; i_gen < PE_COUNT; i_gen = i_gen + 1) begin : gen_mult
            wire signed [8:0] temp_weight;
            assign temp_weight = {1'b0, pe_weight[i_gen]};
            assign prod[i_gen] = pe_data[i_gen] * temp_weight;
        end
    endgenerate

    // --- 逻辑实现 ---

    assign douta = douta_reg;
    
    integer i;

    // --- 同步逻辑块 ---
    always @(posedge clka or negedge rst_ni) begin
        if (!rst_ni) begin
            // --- 异步复位 ---
            state <= IDLE;
            status_reg <= 32'h0;
            douta_reg  <= 32'h0;
            for (i = 0; i < PE_COUNT; i = i + 1) begin
                pe_data[i]   <= 8'b0;
                pe_weight[i] <= 8'b0;
                pe_psum[i]   <= 32'b0;
            end
        end 
        else if (ena) begin
            
            // --- 1. 写操作 (SRAM-like, 最高优先级) ---
            // 只要写使能有效，就立即处理写入
            if (wea) begin
                case (addra)
                    // BASE + 0: 控制寄存器
                    11'h000: begin
                        if (dina == 32'h0000FFFF) begin
                            // START 命令
                            state <= COMPUTING;
                            status_reg <= 32'h00000000;
                        end 
                        else if (dina == 32'hFFFFFFFF) begin
                            // RESET PSUMS 命令
                            for (i = 0; i < PE_COUNT; i = i + 1) begin
                                pe_psum[i] <= 32'b0;
                            end
                            state <= IDLE;
                            status_reg <= 32'h00000000;
                        end
                    end
                    
                    // BASE + 4: PE 1, 2
                    11'h004: begin
                        pe_data[0]   <= dina[31:24];
                        pe_weight[0] <= dina[23:16];
                        pe_data[1]   <= dina[15:8];
                        pe_weight[1] <= dina[7:0];
                    end
                    
                    // BASE + 8: PE 3, 4
                    11'h008: begin
                        pe_data[2]   <= dina[31:24];
                        pe_weight[2] <= dina[23:16];
                        pe_data[3]   <= dina[15:8];
                        pe_weight[3] <= dina[7:0];
                    end
                    
                    // BASE + 12: PE 5, 6
                    11'h00C: begin
                        pe_data[4]   <= dina[31:24];
                        pe_weight[4] <= dina[23:16];
                        pe_data[5]   <= dina[15:8];
                        pe_weight[5] <= dina[7:0];
                    end
                    
                    // BASE + 16: PE 7, 8
                    11'h010: begin
                        pe_data[6]   <= dina[31:24];
                        pe_weight[6] <= dina[23:16];
                        pe_data[7]   <= dina[15:8];
                        pe_weight[7] <= dina[7:0];
                    end

                    // BASE + 20: PE 9, 10
                    11'h014: begin
                        pe_data[8]   <= dina[31:24];
                        pe_weight[8] <= dina[23:16];
                        pe_data[9]   <= dina[15:8];
                        pe_weight[9] <= dina[7:0];
                    end
                    
                    // 默认: 写入其他地址无效
                    default: begin 
                    end
                endcase
            end // if (wea)

            // --- 2. 读操作 和 状态机 (仅在 'ena' 且 '非写' 时执行) ---
            else begin // (ena && !wea)

                // --- 2a. 读操作 (更新输出寄存器) ---
                case (addra)
                    // BASE + 0: 状态
                    11'h000: douta_reg <= status_reg;
                    
                    // BASE + 24: 结果 PE 1-4
                    11'h018: douta_reg <= { pe_psum[0][7] ? 8'b00000000 : pe_psum[0][7:0], 
                                            pe_psum[1][7] ? 8'b00000000 : pe_psum[1][7:0], 
                                            pe_psum[2][7] ? 8'b00000000 : pe_psum[2][7:0], 
                                            pe_psum[3][7] ? 8'b00000000 : pe_psum[3][7:0]};
                    
                    // BASE + 28: 结果 PE 5-8
                    11'h01C: douta_reg <= { pe_psum[4][7] ? 8'b00000000 : pe_psum[4][7:0], 
                                            pe_psum[5][7] ? 8'b00000000 : pe_psum[5][7:0], 
                                            pe_psum[6][7] ? 8'b00000000 : pe_psum[6][7:0], 
                                            pe_psum[7][7] ? 8'b00000000 : pe_psum[7][7:0]};
                    
                    // BASE + 32: 结果 PE 9-10
                    11'h020: douta_reg <= {pe_psum[8][7] ? 8'b00000000 : pe_psum[8][7:0], 
                                           pe_psum[9][7] ? 8'b00000000 : pe_psum[9][7:0], 
                                           16'h0000};
                    
                    // 默认: 读取其他地址返回 0
                    default: douta_reg <= 32'h0;
                endcase

                // --- 2b. 状态机 (内部状态更新) ---
                // (此逻辑仅在 'wea' 为低时执行)
                case (state)
                    IDLE: begin
                        // 保持IDLE, 等待 'START' 写入
                    end
                    
                    COMPUTING: begin
                        // 行为模型：在一个周期内完成所有PE的乘加
                        for (i = 0; i < PE_COUNT; i = i + 1) begin
                            pe_psum[i] <= pe_psum[i] + prod[i];
                        end
                        
                        // 计算完成，进入DONE状态
                        state      <= DONE;
                        status_reg <= 32'h00000001; // 设置 "完成" 标志
                    end
                    
                    DONE: begin
                        // 保持DONE, 等待 'RESET' 或 'START' 写入
                    end
                endcase
            end // else (!wea)

        end // if (ena)
    end // always

endmodule
